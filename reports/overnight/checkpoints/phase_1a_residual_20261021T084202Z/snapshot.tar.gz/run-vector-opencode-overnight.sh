#!/usr/bin/env bash
set -euo pipefail
umask 077

# VECTOR unattended LOCAL run. Execute from the traderbybit root as a normal WSL user.
# MANUAL ONE-TIME CHECKS: opencode --version; opencode run --help; verify build agent
# and permission semantics on your installed version. This is NOT an OS sandbox.
# Never run with production credentials, access to production SSH, or a shared
# Docker daemon unless the authorized test containers are strongly isolated.

REPO="$(pwd -P)"
SPEC="$REPO/VECTOR_OPENCODE_OVERNIGHT_FULL_EXECUTION_SPEC_EN.md"
SESSION="${SESSION:-vector-night}"
LOG_DIR="$REPO/reports/overnight"
LOG="$LOG_DIR/opencode-session.log"
MAX_HOURS="${MAX_HOURS:-10}"
MODEL="${MODEL:-}"

fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
warn() { printf 'WARN: %s\n' "$*" >&2; }

[[ $(id -u) -ne 0 ]] || fail 'do not run as root. Use a normal WSL user.'
[[ -d "$REPO/.git" || -f "$REPO/.git" ]] || fail 'repository .git marker not found; launch from traderbybit root.'
[[ -f "$REPO/AGENTS.md" || -d "$REPO/research-go" ]] || fail 'expected traderbybit project markers not found.'
[[ -f "$SPEC" ]] || fail "missing spec: $SPEC"
[[ "$SESSION" =~ ^[a-zA-Z0-9_-]+$ ]] || fail 'SESSION must contain only letters, digits, underscores or hyphens.'
[[ "$MAX_HOURS" =~ ^[0-9]+([.][0-9]+)?$ ]] || fail 'MAX_HOURS must be a positive number (e.g., 10 or 0.1).'
awk -v h="$MAX_HOURS" 'BEGIN {exit !(h > 0 && h <= 24)}' || fail 'MAX_HOURS must be greater than 0 and no more than 24.'

required=(git go php node npm psql tar sha256sum df timeout tmux opencode awk)
for cmd in "${required[@]}"; do
  command -v "$cmd" >/dev/null 2>&1 || fail "missing required command: $cmd"
done

for cmd in composer docker shellcheck; do
  command -v "$cmd" >/dev/null 2>&1 || warn "optional command '$cmd' missing. Some phases may be blocked."
done

# Never create a second writer in the same session.
if tmux has-session -t "$SESSION" 2>/dev/null; then
  fail "tmux session '$SESSION' already exists; refusing duplicate workers."
fi

# Confirm flags from installed CLI before a ten-hour unattended run.
if ! CLI_HELP="$(timeout 60s opencode run --help 2>&1)"; then
  fail 'unable to check opencode run --help; resolve installation before starting.'
fi
for flag in --auto --agent --file; do
  grep -Fq -- "$flag" <<< "$CLI_HELP" || fail "OpenCode run does not advertise required option $flag"
done
if [[ -n "$MODEL" ]]; then
  grep -Fq -- '--model' <<< "$CLI_HELP" || fail 'this OpenCode run version lacks --model'
fi

# Require reasonable free space for evidence snapshots, but never perform cleanup.
AVAIL_KB=$(df -Pk "$REPO" | awk 'END {print $4}')
[[ "$AVAIL_KB" =~ ^[0-9]+$ ]] || fail 'unable to determine available disk space.'
(( AVAIL_KB >= 15 * 1024 * 1024 )) || fail 'less than 15 GiB available; free space manually first.'

mkdir -p "$LOG_DIR"
[[ ! -L "$LOG" ]] || fail 'refusing a symlinked log file.'
if [[ -e "$LOG" ]]; then
  ROTATED="$LOG.$(date -u +%Y%m%dT%H%M%SZ)"
  mv -- "$LOG" "$ROTATED"
fi

# Private worktree snapshot: excludes secrets, dependencies, and the snapshot
# directory itself. This is a safety backup, not a cryptographic security boundary.
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
SNAP="$LOG_DIR/worktree-snapshot-$STAMP.tar.gz"
[[ ! -e "$SNAP" ]] || fail "snapshot already exists: $SNAP"
if ! tar -czf "$SNAP" \
  --exclude='.git' --exclude='node_modules' --exclude='vendor' \
  --exclude='.env' --exclude='.env.*' --exclude='*.pem' --exclude='*.key' \
  --exclude='.ssh' --exclude='.aws' --exclude='.gnupg' \
  --exclude='ECONOM' --exclude='econom-group' \
  --exclude='./reports/overnight' --exclude='reports/overnight' \
  --exclude='.cache' --exclude='coverage' --exclude='dist' \
  -C "$REPO" .; then
  fail 'snapshot creation failed; repair backup first. Agent was not started.'
fi
[[ -s "$SNAP" ]] || fail 'snapshot file missing or empty.'
if ! tar -tzf "$SNAP" >/dev/null; then
  fail 'snapshot validation failed; agent was not started.'
fi
SNAP_HASH="$(sha256sum "$SNAP" | awk '{print $1}')"
SPEC_HASH="$(sha256sum "$SPEC" | awk '{print $1}')"
START_EPOCH="$(date -u +%s)"
DURATION_SECONDS="$(awk -v h="$MAX_HOURS" 'BEGIN {printf "%.0f", h*3600}')"
HARD_EPOCH=$(( START_EPOCH + DURATION_SECONDS ))
SOFT_EPOCH=$(( HARD_EPOCH - 3600 ))
(( SOFT_EPOCH >= START_EPOCH )) || SOFT_EPOCH="$START_EPOCH"
if (( SOFT_EPOCH == START_EPOCH )); then
  warn "MAX_HOURS <= 1h: soft deadline equals start; use only for smoke testing."
fi
HARD_DEADLINE="$(date -u -d "@$HARD_EPOCH" +%FT%TZ)"
SOFT_DEADLINE="$(date -u -d "@$SOFT_EPOCH" +%FT%TZ)"

# Auto-approvals are convenient but not a process/filesystem sandbox.
# The catch-all external-directory deny is followed by narrow cache/temp allows.
# Docker socket is NOT granted automatic external-file access; docker CLI with a
# privileged/shared daemon remains risky and must be controlled outside OpenCode.
# Bash auto-approval can bypass read-deny patterns: remove credentials beforehand.
OPENCODE_CONFIG_CONTENT=$(cat <<'JSON'
{"permission":{"*":"allow","external_directory":{"*":"deny","$HOME/go/**":"allow","$HOME/.cache/go-build/**":"allow","$HOME/.npm/**":"allow","$HOME/.cache/composer/**":"allow","/tmp/**":"allow"},"read":{"*":"allow","*.env":"deny","*.env.*":"deny","*.env.example":"allow","*.pem":"deny","*.key":"deny","$HOME/.ssh/**":"deny","$HOME/.aws/**":"deny","$HOME/.gnupg/**":"deny"},"edit":{"*":"allow","*.env":"deny","*.env.*":"deny","*.pem":"deny","*.key":"deny","$HOME/.ssh/**":"deny","$HOME/.aws/**":"deny"}}}
JSON
)

# Reject malformed permission JSON rather than risking fallback permissions.
if command -v python3 >/dev/null 2>&1; then
  printf '%s' "$OPENCODE_CONFIG_CONTENT" | python3 -c 'import sys,json; json.load(sys.stdin)' \
    || fail 'OPENCODE_CONFIG_CONTENT is not valid JSON'
else
  fail 'python3 is required for permission JSON validation'
fi

# Explicit operator opt-in for a user with access to the shared Docker daemon.
# This does NOT isolate Docker or prevent shell command workarounds.
# Run only after manually starting and verifying an isolated test PostgreSQL.
DOCKER_GROUP_PRESENT=0
if id -nG | tr ' ' '\n' | grep -qx docker; then
  DOCKER_GROUP_PRESENT=1
  if [[ "${ALLOW_SHARED_DOCKER_RISK:-0}" != "1" ]]; then
    fail 'docker-group access detected. To accept shared-daemon risk explicitly, set ALLOW_SHARED_DOCKER_RISK=1 after verifying test DB and credentials.'
  fi
  warn 'SHARED DOCKER RISK ACCEPTED: OpenCode shell commands can still reach the Docker daemon. Instructions alone cannot enforce isolation.'
fi

# Keep filenames/private paths in a mode-0600 preflight log.
{
  echo "# Preflight $(date -u +%FT%TZ)"
  echo "# Repo: $REPO"
  echo "# User: $(whoami) (uid=$(id -u))"
  echo "# Git HEAD: $(git -C "$REPO" rev-parse HEAD 2>/dev/null || echo unknown)"
  echo "# Branch: $(git -C "$REPO" branch --show-current 2>/dev/null || echo unknown)"
  echo '# Git status (first 100):'
  git -C "$REPO" status --short 2>/dev/null | head -100 || true
  echo '# Git diff stat (last 20):'
  git -C "$REPO" diff --stat 2>/dev/null | tail -20 || true
  echo '# Toolchain:'
  echo "  go: $(go version 2>/dev/null)"
  echo "  php: $(php -v 2>/dev/null | head -1)"
  echo "  node: $(node --version 2>/dev/null)"
  echo "  npm: $(npm --version 2>/dev/null)"
  echo "  psql: $(psql --version 2>/dev/null)"
  echo "  opencode: $(opencode --version 2>/dev/null || echo unknown)"
  echo "# Model: ${MODEL:-default}"
  echo "# Disk: $(df -h "$REPO" | tail -1)"
  echo "# Spec SHA-256: $SPEC_HASH"
  echo "# Snapshot: $SNAP"
  echo "# Snapshot SHA-256: $SNAP_HASH"
  echo "# MAX_HOURS: $MAX_HOURS"
  echo "# SOFT_DEADLINE_UTC: $SOFT_DEADLINE"
  echo "# HARD_DEADLINE_UTC: $HARD_DEADLINE"
  echo "# Docker group present: $DOCKER_GROUP_PRESENT (risk opt-in: ${ALLOW_SHARED_DOCKER_RISK:-0})"
  echo '# DB isolation: UNVERIFIED (do not use production DB; verify test connection before migrations)'
  echo '# END PREFLIGHT'
} > "$LOG"

cat > "$LOG_DIR/PREFLIGHT.md" <<EOF
# Overnight preflight

- UTC start: $(date -u +%FT%TZ)
- Git HEAD: $(git rev-parse HEAD)
- Spec SHA-256: $SPEC_HASH
- Snapshot: $SNAP
- Snapshot SHA-256: $SNAP_HASH
- Soft shutdown UTC: $SOFT_DEADLINE
- Hard shutdown UTC: $HARD_DEADLINE
- Test DB isolation: NOT_VERIFIED; require local isolated verification before any migration
- Docker-group present: $DOCKER_GROUP_PRESENT (operator risk opt-in: ${ALLOW_SHARED_DOCKER_RISK:-0})
- NOTE: This script does not sandbox arbitrary Bash, Docker, SSH or network access.
EOF

cat > "$LOG_DIR/RUN_STATUS.md" <<EOF
# Run status — $(date -u +%FT%TZ)

| Phase | Status | Started UTC | Finished UTC | Evidence |
|---|---|---|---|---|
| PRECHECK | DONE | $(date -u +%FT%TZ) | $(date -u +%FT%TZ) | reports/overnight/PREFLIGHT.md |
| IMPLEMENTATION | NOT_STARTED | — | — | — |

## Last update: $(date -u +%FT%TZ)
EOF
: > "$LOG_DIR/CHANGES.md"
: > "$LOG_DIR/BLOCKERS.md"

TASK_PROMPT="Execute the attached VECTOR v1.1 overnight LOCAL engineering contract. Routine local edit/test permissions are approved within the contract only. Preserve dirty QIM/G1/P-1 changes; all production, live-order, P-3, ECONOM and destructive Git operations remain prohibited. Implement sequential evidence-gated stages, record durable checkpoints, and do not fake performance or financial results. SOFT SHUTDOWN UTC: $SOFT_DEADLINE; HARD DEADLINE UTC: $HARD_DEADLINE. At the soft deadline stop starting phases and finalize logs, checksums, and NEXT_SESSION_PROMPT.md. If blocked, continue only safe independent work. DO NOT run docker, docker compose, docker-compose, sudo, or alter Docker services/volumes/containers; the operator pre-starts isolated test services. Use only the verified test PostgreSQL via localhost TCP; never use production DB. IMPORTANT: P-2 RiskCapitalMetricsService and its migration already exist as uncommitted work; inspect and finish, do not duplicate."
# IMPORTANT: --file is an array-valued option in OpenCode 1.18.33; if the
# message follows --file, it can be consumed as another filename.
# Put the positional prompt FIRST and --file with its argument LAST.
ARGS=(timeout --signal=INT --kill-after=5m "${MAX_HOURS}h" opencode run "$TASK_PROMPT" --auto --agent build)
[[ -z "$MODEL" ]] || ARGS+=(--model "$MODEL")
ARGS+=(--file "$SPEC")

# Shell-escape all user-configurable values before handing a command to tmux.
printf -v COMMAND '%q ' "${ARGS[@]}"
printf -v REPO_Q '%q' "$REPO"
printf -v LOG_Q '%q' "$LOG"
printf -v CONFIG_Q '%q' "$OPENCODE_CONFIG_CONTENT"
printf -v HARD_Q '%q' "$HARD_DEADLINE"
INNER="cd $REPO_Q && { OPENCODE_CONFIG_CONTENT=$CONFIG_Q $COMMAND >> $LOG_Q 2>&1; rc=\$?; printf '%s\\n' \"# Finished UTC=\$(date -u +%FT%TZ) exit=\$rc\" >> $LOG_Q; exit \$rc; }"

tmux new-session -d -s "$SESSION" "$INNER" || fail 'tmux could not start OpenCode.'

printf 'Started: %s (MAX_HOURS=%s)\nLog: %s\nSnapshot: %s\n' "$SESSION" "$MAX_HOURS" "$LOG" "$SNAP"
printf 'Soft shutdown UTC: %s\nHard deadline UTC: %s\n' "$SOFT_DEADLINE" "$HARD_DEADLINE"
printf 'Watch: tail -f %q\nSession: tmux attach -t %q\n' "$LOG" "$SESSION"
printf 'Stop: tmux kill-session -t %q (may not stop orphan child processes).\n' "$SESSION"
printf 'Inspect remaining processes before any targeted termination: pgrep -af "opencode|phpunit|go test|npm"\n'
printf 'Recover: read reports/overnight/{PREFLIGHT,RUN_STATUS,BLOCKERS,NEXT_SESSION_PROMPT}.md and the last log lines.\n'
printf 'Validate snapshot: tar -tzf %q | head\n' "$SNAP"
