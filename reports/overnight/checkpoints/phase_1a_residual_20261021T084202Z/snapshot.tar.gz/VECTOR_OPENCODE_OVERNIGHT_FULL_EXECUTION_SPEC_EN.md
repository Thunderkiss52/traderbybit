# VECTOR — Unattended Local Engineering Execution Contract

**Version:** 1.1  
**Supersedes:** 1.0  
**Change log:** phase checkpoints (§0.6); dirty-worktree preservation (§0.7); shadow/P-3 distinction (§6/§8); look-ahead controls (§7.7); expected inconclusive candidates (§7.8); evidence templates (§9.3); deadline/soft shutdown (§10.6); scoped stop/recovery (§11.1).

**Purpose:** one substantial unattended OpenCode development run covering audit fixes, Go research-engine optimization, outstanding PROFIT-1 packages, five candidate-strategy research implementations, and the evidence-gated autonomous *paper-only* research loop.

**Status:** User authorizes all **local project development, tests, isolated test DB migrations, repository-local documentation, and research-only simulations** within this contract. Permission prompts can be auto-approved within this scope. The user has NOT authorized production deployment, production migrations, live exchange orders, access to ECONOM, Git push, or destructive Git operations.

**Operating rule:** IMPLEMENT AND VERIFY. Do not produce a new speculative plan and stop. Work through the phases sequentially, preserving durable checkpoints and evidence. If an individual phase fails a hard correctness gate, fix it if possible; if impossible, mark it `BLOCKED`, preserve evidence, and continue only with safe independent tasks. Never bypass the gate or claim later dependent phases completed. At the end, return a clear truthful summary of implemented vs incomplete work. You may run unattended and use helper agents without requesting routine user approvals.

## 0. Working tree and source-of-truth preflight

1. Run as the ordinary WSL user inside the existing `traderbybit` repository, not as root. Confirm exact repo root, `git rev-parse HEAD`, `git status --short`, available branches, environment constraints, Go version, PHP version, PostgreSQL test configuration and services. The worktree may be dirty with QIM, G1 and P-1 implementation. **Do not reset/clean/overwrite/revert existing changes**. Do not start a clean worktree from HEAD and silently lose uncommitted QIM/G1/P-1 changes.
2. Read `AGENTS.md`, `VECTOR_AUTONOMOUS_PROFIT_RESEARCH_MASTER_SPEC_V1_EN.md`, `VECTOR_PROFIT_1_Revision_2_1_Full_Spec.md`, `reports/profit-growth/00-capability-and-data-inventory.md`, `reports/profit-growth/01-g1-read-only-economics-foundation.md`, `reports/profit-growth/02-p1-slippage-attribution.md`, relevant G1/P1 evidence, existing Go research documentation and strategy risk/Gate 6 configuration. Locate by actual paths and report absent files; do not invent names/content.
3. If present in repo, use `vector-audit.tar.gz` (or the accessible audit extracted logs) as reproducible diagnostic leads, not proof that all audit conclusions are correct. Document evidence source paths and tests.
4. Inventory existing functionality before adding anything. Reuse and fix existing classes, queues, schemas, and Go worker. Make source changes in bounded, reviewable groups; checkpoint after each successful phase.
5. Create `reports/overnight/` and maintain `RUN_STATUS.md`, `COMMAND_LOG.md`, `CHANGES.md`, `BLOCKERS.md`. Update on each phase boundary so an interrupted overnight run still yields useful deliverables. Do not write secrets or personal data into reports.


### 0.6. File-based checkpoints and recovery evidence

`git commit`, `git push`, `git reset`, `git clean` and `git checkout --` are prohibited. At every phase boundary, save a phase checkpoint under `reports/overnight/` with a UTC suffix, recording changed-file diff (`git diff --binary HEAD`, subject to redaction of secrets), untracked file inventory, `git status --short`, and a compressed source snapshot using the launcher's exclusion set. Exclude `reports/overnight/` itself to prevent recursive snapshots; exclude `.git`, `.env*`, private keys, `vendor`, `node_modules`, ECONOM and large generated build caches. Validate archive integrity (`tar -tzf`) and record its SHA-256, size and path in `RUN_STATUS.md`. **A checkpoint failure is a blocker to beginning the next destructive editing phase; do not silently continue.** Do not automatically restore from an archive over user files; it is an operator-controlled recovery source. Avoid unlimited snapshots if disk capacity is insufficient; mark `CHECKPOINT_BLOCKED` and stop further modifications.

### 0.7. Dirty-worktree merge and conflict handling

The repository can contain uncommitted QIM, G1 and P-1 changes. Before editing an existing file, examine its current content, `git diff -- <file>` and `git log -1 -- <file>`. Apply new changes on top of existing hunks and preserve user edits. If an ambiguous conflict cannot be resolved without overwriting user changes, record `DIRTY_WORKTREE_CONFLICT` and source diffs in `BLOCKERS.md`; continue only with independent, nonconflicting work. Never use `git checkout --`, `git restore`, `git reset` or `git clean` to discard those changes.

## 1. Highest-priority reliability fixes from OpenCode audit

### 1A. PHP backtest crash

- Reproduce `Undefined array key "opened_at"` in `app/Backtest/Application/BacktestSimulationEngine.php` (previous audit referred to line ~236; recheck actual lines). Trace data shape and lifecycle of all open/closed/partial positions; correct root cause rather than adding misleading default dates.
- Reproduce and diagnose the separate `InvalidArgumentException: Illegal operator and value combination` with the recorded test/strategy override when possible. Avoid constructing invalid SQL queries with nullable comparison operands; preserve the intended time range and filter logic.
- Add regressions for no trades, open positions, partial exits, missing/invalid timestamps, range boundaries and 3-day backtest. Confirm no look-ahead introduced.
- If an error requires production data or unavailable prerequisites, report precisely and add test coverage for the reliable reproducer.

### 1B. Isolated PostgreSQL test-account mismatch

- Reproduce the audit's expected 8 primary accounts versus 9 observed in `bybit_test` without touching production.
- Determine whether the extra record comes from fixtures, migration rehearsal, reuse of test data, or a real code defect. **Never delete/merge/reinitialize paper accounts indiscriminately.** Only adjust fully isolated test fixtures and test setup with explicit non-production DB verification.
- Regression: stable 8-primary-account invariant, correct cleanup/isolation between tests, and preservation of all actual user history.

### 1C. End-to-end signal and account safety

- Run focused read-only checks for signal lifecycle, terminal decisions, trade execution idempotency, reconciliation and the eight existing strategy accounts. Fix actual test-proven regressions only. Do not change strategy rules to artificially create trades.

## 2. Go backtest profiling and evidence-based optimization

- Start with existing `research-go`; inventory existing BACKTEST, PATTERN_DISCOVERY, WFO, and MONTE_CARLO functionality and the queue contract.
- Audit observations are **not a PHP-vs-Go speed comparison**: historical PHP benchmarks often measured indicators while Go benchmarks measured whole backtests. Do not cite these as language-level performance.
- Reproduce isolated synthetic datasets of 2,000 / 5,000 / 10,000 candles plus a representative realistic data set when available, without sending credentials or financial account data outside the repo. Measure end-to-end and algorithm-only wall time, CPU, peak RSS, allocations, DB/Redis I/O, queue wait, result sizes; run at least 3 comparable trials and record environment/variance. Use Go pprof CPU/heap profiling and benchmark tests as appropriate.
- Investigate pathological growth (rough audit observations: Go BACKTEST 1.199s at 2k, 12.417s at 5k, 82.597s at 10k; validate numbers independently). Identify repeated entire-history scans, indicator recomputation, N^2 loops, per-candle SQL calls, excessive allocations and serialized workers.
- Optimize based on measured hotspots: precomputed rolling indicators, incremental statistics, indexed windows, bounded buffers, reduced allocations, batched DB fetching, safe parallelism. Maintain exact strategy event semantics, fill ordering, fees, funding, stop/TP handling, risk and per-account isolation.
- Golden parity tests compare strategy signals, trade events, entry/exit times, execution prices, decisions, accounting inputs, and stable output hashes, not just aggregate PnL. For any expected change from a proven bug fix, retain before/after source-backed diffs and explain it. Detect no look-ahead.
- Three independent test/benchmark cycles: baseline, after first optimization, final regression. No fabricated speedup target. If workloads are already fast enough or the bottleneck is elsewhere, do not rewrite them for the sake of Go.
- Preserve Laravel/PHP/PostgreSQL as the authoritative exact-decimal financial accounting and Gate 6 decision contour. Do not duplicate ledger monetary arithmetic in Go using float64. A numerical equality requirement demands verified decimal parity.
- `Pattern Discovery`, `WFO`, and `Monte Carlo` should be improved **only where evidence identifies defects or shared bottlenecks**. Do not over-engineer.

## 3. Close prior P-1 correctness and implement PROFIT-1 P-2

- Check actual status of P-1 and G1. Verify reference-price reconstruction assumes adverse-only simulator slippage and cannot represent favorable real fills. Preserve `RECORDED_SIMULATOR_ADVERSE_RECONSTRUCTED` or compatible accurately documented provenance.
- **Critical partial-close issue:** The historical 29-position/65-execution fixture contains one `PARTIALLY_CLOSED` position with entry quantity 0.021 and exited quantity 0.010, leaving 0.011 open. The entire entry slippage of 0.021 cannot automatically be added to **realized** lifecycle net PnL from exited quantity 0.010. Verify matching execution IDs, cutoffs and PnL populations; allocate entry slippage proportionally to realized vs open inventory according to verified ledger conventions. Keep total full-fill execution slippage separate from realized-only counterfactual. If matching is inconclusive, mark hypothetical net `NOT_VERIFIED`, rather than forcing 72.6789 USDT. Add negative controls.
- Implement P-2 **exactly per PROFIT-1 Rev 2.1 sections 6, 8 and 18**, reusing existing `QuantPortfolioMetricsService`, `PerformanceStatisticsService`, `DailyPerformanceService`, P-1 service and ledger reconciliation. Do not rebuild V5.3 accounting.
- Deliver position-level net R, mean/median R; cost-to-risk using matched-scope P-1 data; net profit factor, net win rate and payoff; drawdown using valid initial high-water mark and timestamped equity, time underwater; bounded carry-forward TWAE with uncovered gaps; turnover; daily returns and daily realized net R; dependence-aware ESS per normative method; source-backed risk-capital/notional/exposure measurements; margin only where directly recorded (else `NULL`/`NOT_RECORDED_IN_LEDGER`).
- Source cutoff and `known_at` constraints. Handle partial exits, unclosed positions, missing risk capital, zero denominators, signed funding and external flows explicitly. 20 non-overlapping valid days and ESS >=20 are **minimum data sufficiency gates**, not proof of positive expectancy. Honor stricter existing policy.
- Use append-only immutable research generations, valid idempotency payload hashes, heartbeat/stale-job/retry semantics, performance-bounded separate research queue and no ledger writes. Test migration only on isolated test DB. No synchronous long-running HTTP computations.
- Complete the specified API and Russian Quasar UI and create `reports/profit-growth/03-p2-risk-and-capital-efficiency.md` and `reports/profit-growth/P2_evidence.json` with genuine raw evidence and limitations.

## 4. Implement PROFIT-1 P-5 (separate verified change set)

After P-2 is accepted locally, implement **section 10 / relevant §18** exactly:
- Inclusive/exclusive time-interval semantics as specified; analyze same-side overlaps and **opposite-side overlaps as a bipartite graph**. Never infer nonexistent pairwise edges from connected components.
- Detect concentration of net outcome in individual positions, days, symbols, directions, regimes and overlapping market episodes. Audit any duplicated or transitive counting.
- Synchronize equity time series only where timestamps/data coverage support it; do not silently forward-fill unlimited gaps. Use source-backed samples, proper status and ESS where applicable.
- Full reproducibility, independent eight-account reporting, read-only APIs/UI, golden and negative controls, PostgreSQL integration, evidence manifest/report.
- Do NOT combine the eight primary paper ledgers or mistake overlapping observations for independent samples.

## 5. Implement PROFIT-1 P-4 (separate verified change set)

After accepted P-1 and required upstream dependencies, implement **section 9 / relevant §18**:
- Account for actual ledger costs and independently reported P-1 simulator drag with matched event scope; no double-subtraction and no assertion that full drag is recoverable.
- Report fees, signed funding, slippage attribution, gross-positive/net-negative cohorts with source references and honest data coverage.
- Observed-position MFE/MAE from eligible candles within actual historical holding interval, with realistic same-candle ambiguity handling.
- Separate pre-entry forecast features from ex-post observations; event/known-at cutoffs prevent look-ahead. No fabricated intrabar sequence, hypothetical fills, or execution improvements.
- Implement required immutable generations, API/UI and tests, evidence.
- Do NOT change TP/SL, fees, maker execution, risk policy or strategy filters.

## 6. Implement PROFIT-1 P-6 (last profitability package)

Only after all P-1, P-2, P-4, P-5 acceptance checks pass, implement **sections 11, 14, 18**:
- Versioned immutable decision records; normative enum states and explicit `INSUFFICIENT_EVIDENCE`, `COLLECT_MORE_DATA` and `EVIDENCE_NEGATIVE` outcomes as appropriate.
- Risk-adjusted after-cost evidence and calibrated uncertainty / overlapping-dependence / preregistration / multiple-testing effects.
- Complete Russian Profitability Research UI with three view presets, filters, source-to-result provenance, exports, and valid cohort/cutoff/coverage indicators. Keep combined portfolio views strictly `RESEARCH_ONLY_COMBINED_VIEW`.
- P-3 rejected-signal SHADOW replay remains **PROHIBITED**. Never simulate forbidden skipped or risk-rejected signals as executed trades. Mark conclusions requiring it `NOT_EVALUATED`. In this contract, Gate 6 paper-challenger shadow is a distinct forward paper observation stream; it never authorizes P-3 replay or synthesizing forward outcomes from rejected signals.
- P-6 outputs are recommendations/evidence only. They do not automatically modify live or paper strategies. Do not claim statistical profit without sufficient samples.
- Complete evidence and negative controls. If any upstream package fails, P-6 may remain partial but cannot be labeled verified.

## 7. Five additional strategy candidates: research implementation only

Build or extend Go research logic to evaluate these **five candidate hypothesis families** using a common versioned backtesting and OOS pipeline:

1. `funding_open_interest_squeeze` — funding rate, open interest change, position crowding and reversal/continuation hypotheses. Validate publication/data availability and funding cashflow sign.
2. `liquidity_sweep_reversal` — S/R false-break and level-recapture features, prior-known support/resistance levels; avoid hindsight swing points.
3. `volatility_compression_breakout` — Bollinger/Keltner/ATR or equivalent precommitted volatility compression followed by confirmed breakout; account for intrabar ambiguity.
4. `btc_eth_lead_lag` — aligned BTC and ETH data at decision-time and lagged relationships; account for cross-symbol execution and covariance. Do not label guaranteed arbitrage. If engine cannot execute truly isolated pair legs with coherent financing and concurrency, research the signal only with `EXECUTION_NOT_VALIDATED`.
5. `multi_timeframe_trend_following` — higher-timeframe trend, lower-timeframe entry confirmation. Guarantee higher-timeframe candles are **fully closed** and available at entry, never peek into future closes.

Before coding each, check whether the same logic exists already in `trend_pullback`, `momentum`, `support_resistance_bounce`, `support_resistance_breakout`, `donchian_atr_breakout` or others. Prefer parameterized extensions or challenger research over redundant production strategies.

Requirements:
- **Maintain exactly eight original PRIMARY paper accounts with unmodified ledgers and the existing eight strategies.** Five candidates are research cohorts, NOT five automatically activated production paper accounts. Create isolated research IDs / candidate result tables, not additional primary accounts.
- Reuse existing Go engine and published market data from locally available stored datasets; verify market/event/known-at time, QIM provenance, gaps, stale data and symbol alignment. No speculative claims if data unavailable.
- Version rules, feature schema, seeds, source hashes, cost/funding model and entry/exit assumptions. Positive expected value must be **net after simulated transaction costs** and backed by independently held-out OOS + prospective paper/shadow evidence; a single backtest or one-day historical audit cannot establish this.
- Prevent data leakage, multiple-hypothesis fishing, survivorship and regime cherry-picking. Include null / deliberately adversarial controls, synthetic/golden tests and exact reproducibility. Report even negative results; no guaranteed win rate.
- Do not open real exchange orders, use exchange trade keys, or change existing baseline accounts.


### 7.7. Mechanical look-ahead controls for every candidate

- **Higher-timeframe candle closure:** every HTF feature for a lower-timeframe entry must use a candle that was fully closed and known at decision time (`entry_decision_ts >= htf_candle.close_ts` and `known_at <= entry_decision_ts`). When comparing bar-open or close timestamps, explicitly identify which they represent.
- **Causal indicator test:** for each output at decision time `t`, mutate all candles/events whose `known_at > t`; earlier feature values and signals must remain unchanged. If the strategy uses a previous closed bar at `t-1`, assert the expected `t-1` cutoff separately.
- **Negative control:** deliberately inject a future-only feature into the historical input; this must make the causal test fail. A negative control that passes indicates the test is invalid, not that look-ahead is safe.
- Run the above alongside golden parity tests for every candidate. Without them, status is `NOT_EVALUATED`, not `VERIFIED`.

### 7.8. Valid negative or unevaluable candidate outcomes

- `funding_open_interest_squeeze`: `NOT_EVALUATED / DATA_UNAVAILABLE` if correctly timestamped funding/OI data cannot be proved.
- `btc_eth_lead_lag`: `EXECUTION_NOT_VALIDATED` if reliable two-leg execution, synchronized exposure, financing and concurrency cannot be modelled; research the signal without simulating fictitious fills.
- Any candidate lacking required OOS, ESS or prospective paper history: `INSUFFICIENT_EVIDENCE` / `NOT_ELIGIBLE`, not profitable.
- Negative results are valid research outputs; do not tune selection criteria after inspecting held-out results.

## 8. Autonomous paper-only A0–A3 — sequential gated engineering

The user expressly authorizes local **development and isolated verification** of the entire A-series, while preserving paper-only boundaries. Treat internal promotion and virtual deployment as separate operational events requiring evidence gates below. Develop gradually, using the existing Master Spec §4.8 and §5 as product requirements; if it conflicts with a later authorization status, record this instruction as authorization for **local implementation/testing only**.

**A0 — automated candidate hypothesis research:** structured immutable candidate registry; deterministic features; problem statement, evidence population, precommitted null hypothesis, net-after-cost metric, train/OOS/forward splits, familywise experiment count, data-quality and sample coverage. Candidate generation can be autonomous in an isolated environment but cannot modify operational strategies.

**A1 — versioned paper challenger controller:** independent research cohorts and optional isolated local challenger paper simulations. Preserve original eight primary accounts. No rejected-signal replay P-3. Track every attempt, invalidation and failed test. No retrospective threshold fitting using OOS outcomes.

**A2 — autonomous paper-only adoption with safe rollback:** implement and test a controller that selects/promotes only genuinely validated candidate versions **inside isolated paper mode**. Reuse Gate 6 from repository without weakening any threshold (train>=300, OOS>=100, shadow>=100, 14 days/50 trades and further actual configured risk/LCB requirements, or stricter current config). **Here "shadow" means forward observations of an isolated paper challenger, NOT P-3 rejected-signal replay. If the prospective shadow history is unavailable, return `NOT_ELIGIBLE / SHADOW_HISTORY_ABSENT`; this is the correct expected outcome in an overnight build.** Disallow candidate promotion when evidence insufficient. Fail closed; zero eligible candidates is a valid result. Produce immutable approvals, source IDs, rollback triggers and kill switch. **Do not activate autonomous modification of the existing eight operational accounts from this unattended run.** Feature flag OFF by default; acceptance in a local isolated test environment only. User can later explicitly authorize activation in paper production.

**A3 — portfolio/risk-budget research:** research-only allocation simulations and correlation-aware budgeting proposals, never automatically increase risk exposure or merge primary account ledgers. Implement experimental isolated decision logic only if validated prerequisites exist. Live/account-level portfolio risk-budget writes remain OFF until separately authorized.

**No real trading execution path.** Even complete A2 passing Gate 6 must not activate real orders. The possible real-execution future stage remains design-only, not authorized.

## 9. API, test, and evidence acceptance across all phases

- Adhere to exact real schemas and existing code; do not assume migrations or methods exist. Apply additive migrations **only against isolated test DB**. Do not mutate production or VPS, trigger deployment workflows or restarts.
- Full PHPUnit suite and targeted PostgreSQL integration, Pint, Vue tests/build, Go unit/race/vet where applicable. Check actual commands and environment; record exit codes and raw stdout/stderr, not invented counts.
- Targeted endpoint smoke checks on test/local environment, covering G1/P-1/P-2/P-5/P-4/P-6, auth, pagination and source correctness. No claims about production endpoints without production verification.
- Test expected failure modes: 0 denominator, missing prices, partial exits, same-bar ambiguity, empty trade set, duplicate jobs, stale heartbeat, worker crashes, incorrect source hashes, incompatible accounting scopes, sample insufficiency, 8-account isolation, rejected-signal replay refusal, no real orders, ability to rollback paper challenger.
- Use exact decimal arithmetic for authoritative financial metrics; deterministic timestamp UTC and half-open intervals; never replace unsupported metrics with 0.
- Add and run concurrency/synthetic recovery tests for research queues and resource isolation. Preserve priority of market ingestion, paper execution and queues over research jobs; bounded CPU/RAM/worker concurrency. Do not change Redis eviction policy indiscriminately.
- Three rounds for any major algorithm fix: baseline reproducible failure, fixed-target test, full regression. Preserve meaningful profiles/golden parity outputs.
- Ensure frontend clearly distinguishes actual paper ledger vs counterfactual, historical archive vs current production, real market vs synthetic evidence, observed vs modelled slippage, `NOT_VERIFIED` vs accepted claim.
- Each phase: `IMPLEMENTED`, `VERIFIED`, `BLOCKED`, `SAFETY`, `DELIVERABLES`, `NEXT`; raw logs + versions + checksums + migration status + limitation descriptions; ensure re-running is idempotent.
- Never fake success when a test DB is missing or a dataset is too short for Gate 6. **Do not invent a 14-day challenger history overnight.** A0/A1 can be engineering-complete locally while evidence-gated promotions stay NOT_ELIGIBLE.


### 9.3. Minimum report and evidence schemas

Maintain these files from the start. Do not label a phase `VERIFIED` until test commands, exit codes, prerequisites, evidence paths and limitations are recorded.

`reports/overnight/RUN_STATUS.md`:

```markdown
# Run status — <UTC start>
| Phase | Status | Started UTC | Finished UTC | Evidence |
|---|---|---|---|---|
| PRECHECK | DONE | ... | ... | reports/overnight/PREFLIGHT.md |
| 1A | IN_PROGRESS | ... | — | — |
## Last update: <UTC>
```

`reports/overnight/CHANGES.md`: append per-phase UTC timestamp, files touched, summary, tests added and unresolved risks.

`reports/overnight/BLOCKERS.md`: append a unique blocker identifier, phase, machine-readable reason (`DIRTY_WORKTREE_CONFLICT`, `TEST_DB_ISOLATION_UNVERIFIED`, `DATA_UNAVAILABLE`, `SHADOW_HISTORY_ABSENT`, `CHECKPOINT_BLOCKED`, `OTHER`), evidence path, and next safe action.

P-2/P-4/P-5/P-6 evidence JSON minimally records `generation_id` (if a real generation exists; otherwise `null`), `git_head`, `created_at`, `data_cutoff`, `known_at_cutoff`, `metrics`, `coverage` (`days`, `positions`, `ess` as nullable values), `provenance` (sources and hashes), `limitations`, and status (`VERIFIED`, `NOT_VERIFIED`, `INSUFFICIENT_EVIDENCE`). **Never populate missing numbers with zero or fake UUIDs.**

## 10. Operational constraints / permissions contract

AUTO-APPROVE **all routine development permission requests** for editing files within the repository, reading nonsecret source/specs, adding tests, using isolated local Docker Compose test services, installing project-local nonprivileged dependencies where required, benchmarking/profile collection, running safe dev commands, writing logs and research-only simulation jobs. Do not ask the human to approve each file edit, unit test, local database test migration or tool invocation.

**Hard prohibitions, not bypassable via permission auto-approval:**

- No live Bybit orders, trading API credentials, withdrawals, liquidation of real assets, or adding live-trade integration.
- No production deploy, production DB migrations, CI/GitHub Actions trigger, GHCR publish, remote SSH/SCP, changing server configs, or running any operation on VPS.
- No `git push`, `git commit`, `git reset --hard`, `git clean -fdx`, `git checkout -- <files>`, force update, rebases against dirty worktree, or discarding uncommitted data. No repository-wide deletion or global Docker prune.
- Do not read/write ECONOM / econom-group, its images, containers, volumes, cache, backups or shared resources. No cross-project cleanup, even for allegedly orphaned objects.
- Do not access or print secrets (`.env`, SSH keys, auth tokens) without explicit new user authorization; do not transmit code, archives or private market/user data externally for benchmark services.
- No modification of existing eight primary paper ledgers, balances, strategy activation, risk limits, or main trading execution flow except narrowly scoped verified bug fixes that preserve semantics. No unattended promotion into the operational paper environment; experimental challenger implementations feature flag OFF.
- P-3 rejected-signal shadow replay remains prohibited.
- If blocked by environment restrictions, permission safety rule, unavailable independent research data, rate limits or resource budget: document and continue safe independent phases. Do not solve by weakening safety, removing tests or fabricating data.


### 10.6. Nightly timebox and soft shutdown

The launcher provides `MAX_HOURS` (10 hours default) and enforces an external `timeout --signal=INT --kill-after=5m`. The launch prompt must include calculated UTC soft- and hard-deadline timestamps. When the soft deadline (60 minutes before hard deadline) is reached, **stop starting new development phases** and use the remaining time to finalize `RUN_STATUS.md`, `CHANGES.md`, `BLOCKERS.md`, write `NEXT_SESSION_PROMPT.md` with exact remaining tasks and evidence, and create a final checkpoint. `DEFERRED` is a valid state; a broad contract does not imply overnight completion. Timers and permission config are not a security sandbox; never assume the runtime can block dangerous shell commands from touching other projects.

## 11. Execution order, checkpoints, and stopping conditions

Execute without waiting for routine owner confirmation:

```
PRECHECK
  → AUDIT BUGFIX (PHP, PostgreSQL fixture)
  → GO PROFILE/OPTIMIZE/PARITY
  → P-1 partial-close final sanity → P-2 → P-5 → P-4 → P-6
  → 5 NEW RESEARCH CANDIDATES (Go)
  → A0 → A1 → A2 LOCAL FLAG-OFF → A3 RESEARCH-ONLY
  → COMPLETE FULL REGRESSION + EVIDENCE + FINAL REPORT
```

- Treat each package's established test/evidence gates as **local acceptance gates**. User has approved local development of the entire ordered backlog, not permission to skip proof or alter production.
- If a dependent phase fails, mark it blocked, do not falsify acceptance; continue independent Go profiling or candidate research while safe.
- Use existing helper agents only when they do not introduce conflicting writes or run unauthorized operations. Avoid two agents editing the same files concurrently.
- Keep `reports/overnight/RUN_STATUS.md` and short phase checkpoint summaries up to date. Ensure useful partial work persists even if interrupted by context/token limits.
- **Do not claim all phases can finish overnight**. Provide actual completed work and test results. If incomplete, output an ordered continuation prompt so future OpenCode/Codex can resume without redoing finished stages.
- At final return: `1. IMPLEMENTED`, `2. VERIFIED (commands/results)`, `3. OPEN DEFECTS`, `4. PERFORMANCE BEFORE/AFTER`, `5. PROFIT-1 PACKAGE GATES`, `6. FIVE CANDIDATES AND DATA SUFFICIENCY`, `7. AUTONOMY FEATURE FLAGS / GATE 6`, `8. SECURITY & PROJECT SAFETY`, `9. FILES/EVIDENCE`, `10. NEXT ACTIONS / RESUME COMMAND`.


### 11.1. Scoped stop and recovery (operator procedure)

- Soft stop: notify the agent using the attached session or allow the configured deadline; graceful SIGINT is preferred.
- Manual stop: `tmux kill-session -t vector-night` targets only this session. Inspect remaining `pgrep -af 'opencode|phpunit|go test|npm'` entries **before** termination. Never use broad `pkill -f` commands without identifying exact PIDs and ownership: they can interrupt unrelated projects.
- Crash recovery: inspect `reports/overnight/RUN_STATUS.md`, `BLOCKERS.md`, the last 200 lines of `opencode-session.log`, the last checkpoint's archive test/hash and `NEXT_SESSION_PROMPT.md`. Never restore the tar automatically over a dirty worktree.
- Resume with a fresh local OpenCode session using `NEXT_SESSION_PROMPT.md`, skipping only phases with verified evidence. Revalidate dependencies after an interrupted phase.

**Start implementation now. No extra planning phase and no routine user-permission prompts.**
