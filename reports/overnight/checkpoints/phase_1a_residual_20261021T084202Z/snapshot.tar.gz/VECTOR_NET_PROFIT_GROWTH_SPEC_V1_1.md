# VECTOR — Net Profit Growth & Product Value Execution Spec v1.1

**Status:** Proposed scoped implementation for Codex; operator approval required before applying to the repository.  
**Revision:** v1.1 — G0 audit corrections (a)–(f) applied 2026-10-20 on operator instruction; all other wording inherited from v1.0 unchanged.  
**Repository:** `traderbybit` / VECTOR Bybit research and forward paper-trading.  
**Date:** 2026-10-20.  
**North-star:** Improve *verified, risk-adjusted, cost-adjusted economic performance per unit of capital and time*, not apparent gross PnL, win rate, trade count, leverage, or a claimed cash return.

## 0. Boundaries and precedence

1. **Paper trading only.** Never place real exchange orders or enable live trading. No exchange credentials with trading authority. No live-trading recommendation or automatic deployment.
2. Keep eight independent strategy paper accounts and existing balances, positions, fills, risk policies, ledgers, and attribution intact. No merging capital or histories.
3. Do not change owner risk ceilings, strategy entries/exits, position sizing, Gate 6 promotion thresholds, deployment infrastructure or trading behavior as part of measurement work. Any later paper-only behavioral improvement must satisfy the *existing* authorization and precommitted Gate 6 promotion policy; no shortcut.
4. **Respect existing scope:** `VECTOR_PROFIT_1_Revision_2_1_Full_Spec.md` defines approved read-only research economics and its dependency gates. First inventory what is already implemented. Do not duplicate tables/endpoints/calculation code. Its **P-3 rejected-signal shadow replay remains NOT AUTHORIZED**: no replay tables, jobs, hypothetical fills or claims of missed profits.
5. QIM is governed by `docs/QUOTE_INTEGRITY_SPEC_FINAL.md`, with draft amendments recorded in `docs/QUOTE_INTEGRITY_SPEC_REV2.md` (Rev 2.1; operator to designate the canonical document — see G0 correction (a): the previously referenced `QUOTE_INTEGRITY_SPEC_FINAL_EN.md` does not exist). QIM must not be coupled into paper execution. Link observed integrity incidents to research confidence only when such records exist, with no fabricated measurements.
6. No production deployments, schema migrations, Git commit/push, Docker-wide cleanup or modification of ECONOM/econom-group or shared resources. Never start a real seven-day observation window without operator authorization.
7. Maintain staged development, minimal Laravel/Go architectural changes, reuse existing Go computation only if profiling demonstrates a need and results match deterministic PHP reference implementations.
8. No invented Sharpe, alpha, returns, drawdowns, sample sizes, fills, fee savings, time to profitability, statistical significance or SaaS demand.

## 1. Verified economic reference and limitations

The following values are *recomputed from the historical provided archive* `vector-audit-1d-e534ac49-60de-5263-9685-4bea563094c2.zip` (SHA-256 `54da31d20c396901c723f8f3255ba0bbda1e39d9918664d4b48a3a84d5d1c0b4`), with manifest window **2026-10-18 14:45 UTC to 2026-10-19 14:45 UTC**. They are NOT current live metrics and must be rediscovered from the actual database before implementation acceptance. A second archive `vector-audit-1d-53d90c98-a643-5bd0-8b5b-d3f90bdf7757.zip` (SHA-256 `ee703740899b0b378b1d8adb70f2c6cfb21484a630be41a49783db9917db2d5a`) also exists in the repository root; G0 recorded both — the operator confirms which is authoritative (correction (f)).

| Metric / scope | Historical reference |
| --- | ---: |
| Paper accounts | 8 |
| Original virtual starting capital | 80,000.00 USDT total |
| Exported positions (snapshot) | 29, including 28 closed and 1 partially closed |
| Position-snapshot gross PnL | +142.541066420000 USDT |
| Position-snapshot fees | 104.499815521882 USDT |
| Position-snapshot signed funding | -0.535570456588 USDT |
| Position-snapshot net PnL | +37.505680441530 USDT |
| Fees / gross PnL | 73.3121% (diagnostic only; gross positive for this sample) |
| Total current equity in exported account snapshots | 79,498.241177654195 USDT |
| Equity vs initial combined reference | -0.6272% since account creation, **not a one-day return** |

Accounting identity for this **position-snapshot** population: `gross_pnl - fees + signed_funding = net_pnl`. The export manifest explicitly says `BOUNDED_BEST_EFFORT_NOT_REPEATABLE_READ`, and mutable position snapshots can change after the cutoff. Do not mix position-snapshot totals with event-window fee totals, equity-delta totals, or trading execution populations. Do not infer stable strategy profitability from a single day.

Fees, maker/taker: Bybit public VIP0 baseline for normal perpetual/futures is 0.0550% taker and 0.0200% maker **per filled side** (official Bybit VIP benefits page updated 2026-10-12). Actual rates depend on the account/region/time; the simulator must use explicit versioned configured rates or recorded fills, never claim the baseline is the operator's actual schedule. **Known gap (G0):** simulator rates currently live in unversioned `config/paper.php`; G0/G1 must introduce explicit rate *versioning* as a record-only change (no rate change, no behavioural change). For same 10,000 USDT notional each side, and no extra costs, round trips cost 11.00 USDT taker/taker, 7.50 USDT maker/taker, or 4.00 USDT maker/maker. These are *arithmetic examples*, not guaranteed achievable savings.

Funding: Bybit official documentation defines `position value × funding rate`, settled for open positions at funding times, with sign depending on the side and the rate. Use historical event times and recorded signed funding; no generic fixed funding interval assumption.

**Slippage:** Existing paper execution embeds adverse simulated slippage in its fill price (`PaperExecutionEngine`, `virtual_executions.slippage` is a **price delta**, not USDT). Do not subtract slippage a second time from recorded gross/net PnL. Derive dollar drag only after verifying source-code semantics, side, quantity, reference price and contract multiplier (existing verified derivation: `quantity × slippage` in `PerformanceStatisticsService` only). Distinguish simulated and measured-real provenance. Persisted rows with absent reference/semantics must fail closed with an explicit null reason.

## 2. Product strategy: prioritize measurable levers

| Priority | Lever | Hypothesis to test (not a promised gain) | Decision metric | Authorization |
| --- | --- | --- | --- | --- |
| P0 | Accounting truth and cost diagnostics | Bad fills/fees hide nominal edge | Reconciled net PnL; fee bps; signed funding; simulated slippage drag, net R | Read-only |
| P0 | Strategy-by-regime diagnostics | Some strategies lose only in certain verifiable regimes | Matched OOS cost-adjusted net R, ESS, tail drawdown and coverage | Read-only |
| P1 | Entry execution-cost sensitivity | Better execution policy can sometimes save fees but may lose fills | Prospective **shadow** comparison of execution policies with fill probability and adverse selection | Paper research, gated; no alteration of champion fills |
| P1 | Exit policy experiments | Better TP/SL/timeout configuration may improve net R | Matched historical+prospective OOS net R, downside risk, opportunity cost | Research, existing Gate 6 to promote |
| P1 | Capital utilization / exposure | Some accounts may spend risk budget on low-expectancy trades | Return per time-weighted equity, exposure/risk-capital time, idle capital | Read-only first |
| P2 | Statistical candidate selection | Multiple-testing bias creates illusory winners | Precommitted comparator, holdout, uncertainty and corrections | Existing Gate 6 only |
| P2 | Commercial value validation | The analytics platform may generate actual revenue without live trades | Qualified interviews, waitlist, pilot conversions, margin, retention | Separate product/business decision |

Trade frequency, gross profit, click-through, win rate, and number of AI suggestions are **guardrail diagnostics**, not optimization targets.

## 3. Execution packages

### G0 — Reality audit and source-of-truth map (first)

1. Inspect existing implementations of Profit-1 P0/P-1/P-2/P-4/P-5/P-6, current Gate 6 policy, strategy accounts, ledgers, `virtual_executions.slippage`, versioned fees/funding, risk logs, equity snapshots and QIM availability.
2. Produce `reports/profit-growth/00-capability-and-data-inventory.md`: actual code paths, exact schema, verified data definitions, existing endpoints, gaps, permissions, API risk, code version, test DB state and source provenance.
3. Reproduce the historical reference above *from its original ZIP* and record per-file checksums. Do not use the historical result as acceptance output for an unrelated production window.
4. Produce a current read-only diagnostics export, **only if accessible**. If no access, label `CURRENT_STATE_NOT_VERIFIED` and continue with isolated fixture tests; never substitute historical numbers as current.
5. Before adding tables or code, produce a bounded change list of *missing* functionality. Do not duplicate already-completed PROFIT-1 components.
6. No writes to production; no QIM ingestion enablement.

**G0 gate:** actual status `EXISTS_VERIFIED`, `EXISTS_UNVERIFIED`, `MISSING`, `BLOCKED` for every proposed capability; no unsupported current-profit claim.

### G1 — Net Economic Truth Dashboard (reuse existing PROFIT-1 first)

Provide strategy/account/symbol/regime/cohort reporting with:
- Source-backed gross PnL, actual paper fees, signed funding, net realized/unrealized PnL; source populations and cutoff timestamps visibly differentiated.
- Actual position/fill accounting reconciled to portfolio equity and reconciliation runs; do not silently sum overlapping or mutable populations.
- Fee bps per executed notional; maker/taker mix **only if execution role is known. Otherwise display `UNKNOWN`, not fabricated maker fills.** Current execution path is hardcoded taker (`config/paper.php`: `taker_rate` applied to every fill; `maker_rate`/`default_liquidity` are unused) — therefore fills of record are reported as 100% taker by construction, and **no historical fill may ever be attributed maker** (correction (c)).
- Correctly derived recorded simulator slippage drag (USDT and weighted bps) where source reference exists, without double counting.
- Risk-adjusted net R, ESS, expectancy interval, profit factor, payoff ratio, win rate, drawdown, tail loss, turnover, exposure and capital-time utilization, with mathematically defined denominators and reasons for N/A.
- Cohort filters: strategy version, symbol, regime as known-at time, entry/exit reason, trade duration, data-quality status, sample period, time zone, cost model and source version.
- Attribution by execution side, position role (entry/partial/final exit), funding event, strategy and market context. No unverified “recoverable opportunity”.
- Dashboard states: `CURRENT_DATA_UNAVAILABLE`, `INSUFFICIENT_SAMPLE`, `COST_MODEL_UNVERIFIED`, `SOURCE_SCOPE_MISMATCH`, `EXPLORATORY_ONLY`.

**Accounting invariant:** use decimal-safe deterministic math; reproduce reference totals to source precision; signed funding and open-position treatment must match ledger; recomputation invariant under row ordering and pagination.

**Scenario calculator (read-only):** offer user-controlled *hypothetical* fee variation, e.g. fees × 0.9, with all other quantities held constant and an explicit `SENSITIVITY_ONLY_NOT_EXECUTABLE` label. 10% of historical fees equals 10.4499815521882 USDT mechanically, **not a forecast or available profit**. No synthetic fills. Any maker-eligibility improvement requires G2, not this calculator.

**G1 gate:** 100% of selected source populations reconcile or are explicitly flagged as unresolved; all numeric outputs have a formula, source, scope and code version; never falsely display confidence from one day.

### G2 — Execution Quality Experiment Lab (isolated shadow, not real orders)

Build only if it does not duplicate existing functionality. Separate **observed paper results**, **historical sensitivity analysis**, and **prospective shadow hypotheses**.

Experiments to evaluate:
1. Existing taker-like reference versus *hypothetical* maker entry with an explicit queue/fill model, fee schedule, latency, order expiry, maker-to-taker fallback, missed-fill opportunity cost and adverse selection. Never assume a maker fill occurred because price merely touched a limit; without adequate order-book/event-level evidence, mark `FILL_NOT_IDENTIFIABLE`.
2. Stop/TP/timeout alternatives using identical point-in-time market paths and fills, signed costs and no lookahead. Unobservable intra-bar ordering must be `AMBIGUOUS`, not force-assigned favorable fills.
3. Regime-specific execution policy hypotheses (e.g. low spread/high volatility), but control for selection and lookahead bias.

Design: precommitted policy version, immutable input cohorts and hashes, baseline/challenger pair identity, effective sample size, uncertainty, downside loss, missing-data status, compute/disk caps. A challenger can progress through `PROPOSED -> ANALYSIS -> SHADOW -> ELIGIBLE_FOR_EXISTING_GATE6` but must **never** automatically change deployed code, owner risk ceilings, existing positions or account allocation. Promotion only via pre-existing authorized paper-only Gate 6, without weakening its thresholds. Do not create rejected-signal P-3 shadow replay.

**G2 gate:** a falsification fixture demonstrates that touch-only maker eligibility cannot be reported as a guaranteed fill; fixed scenarios rerun bit-for-bit; no change to champion execution.

### G3 — Robust Strategy/Portfolio Research Scorecard

Produce independent, matched comparison cohorts with:
- Precommitted primary endpoint: cost-adjusted net R per unit of *time-weighted capital* and bounded risk (not raw PnL).
- Minimum samples and ESS according to existing Gate 6; training/OOS/shadow periods strictly chronological, purged/embargoed where overlapping label windows risk leakage.
- Baseline and challenger evaluated on same symbols, windows, costs and known-at features. Evaluate separately BTCUSDT vs ETHUSDT and regime; do not silently pool eight isolated accounts as a shared portfolio.
- Uncertainty estimation that respects serial dependence; bootstrap or other prespecified valid method; multiple-comparison correction across candidates.
- Lower confidence bound and worst-tail / drawdown risk, with `NOT_EVALUABLE` for thin samples.
- Concentration, churn, turnover and exposed risk-capital-time alongside calendar-time coverage.
- Ablation showing whether apparent uplift comes from lower commissions, different exposure, skipped fills or genuine strategy edge.
- Pre-register experiment, stop rules, and report selection counts; failed candidates remain visible in the audit.

**G3 gate:** zero unqualified improvement claims; real candidate must not be auto-promoted based on fixture success. Training and paper-only promotion, if already authorized under the existing promotion policy v4.0.0 (`config/strategy.php`), must go through the existing policy (correction (b): the “V4 authorization” term does not exist in the governing PROFIT-1 spec).

### G4 — Commercial Validation (separate opt-in business track)

Paper trading itself produces no distributable cash PnL. If the operator's objective is **actual income from the product**, validate a research/analytics offering before building billing, brokerage execution, or regulated signal subscriptions.

Deliver a one-page proposition hypothesis and a simple test plan:
- Target segments: quant hobbyists, small systematic traders, research teams, SaaS/data customers (to be validated, not presumed demand).
- Offer candidate: trade cost accounting, data integrity and reproducible research audit; avoid claims of guaranteed returns or advice.
- Pricing: do **not** invent market-validated price. Test price points through operator-approved interviews or optional nonbinding landing-page interest surveys.
- Funnel metrics: qualified leads, conversion into interviews, expressed willingness to pay versus actual signed paid pilots, acquisition cost, gross margin, churn/retention and support hours.
- Privacy/security/legal gate before sharing third-party market data, customer trade history, analytics, or providing regulated investment advice.
- No external outreach, payments, website publication, or customer contact without operator permission.

**G4 gate:** report `DEMAND_UNVERIFIED` unless independent real customer evidence exists. No commercial buildout based on invented conversion rates.

## 4. Product metric contract

Define each metric in a machine-readable metric registry with: ID, definition, unit, formula, denominator, clock, accounting scope, provenance, sign convention, version, sample size, confidence/limitations, applicable statuses and null reasons.

Priority metrics:
- `net_realized_pnl_usdt`, `net_unrealized_pnl_usdt`, `equity_change_usdt`, `net_r`, `weighted_fee_bps`, `simulated_slippage_drag_bps`, `signed_funding_usdt`;
- `net_expectancy_r`, `net_r_lcb`, `effective_sample_size`, `max_drawdown`, `tail_loss`, `profit_factor`, `turnover_notional`, `risk_capital_time`, `time_weighted_average_equity`;
- `eligible_opportunity_count`, `observed_fill_count`, `missed_fill_count` **only where measurable**, `shadow_counterfactual_coverage`, `data_quality_coverage`;
- `risk_per_account`, `strategy_version`, `regime_at_decision`, `pnl_attribution_scope`.

Do not create a composite score named “Profit Score” whose weights were not prespecified. No cross-account transfer assumptions. Missing market quotes, costs or references are `NULL` with explicit reason, not zero.

## 5. Validation & tests

Run tests in three successive iterations: (1) focused affected-unit and deterministic fixtures, (2) isolated PostgreSQL/concurrency and API tests, (3) complete regression plus repeat-run deterministic evidence. Fix failures between iterations. Include:

1. 24h audit-reference reconciliation to 12 decimal places (source-scale aware) for consistent position snapshot population.
2. Trade gross/fees/signed funding/net identity; avoid multiplying or subtracting simulator slippage twice.
3. `virtual_executions.slippage` dollar conversion requires verified units/reference/quantity and clearly fails closed when absent.
4. Taker/taker, maker/taker, maker/maker examples: 11.00/7.50/4.00 USDT on 10k notional each side for VIP0 reference. Fee rates are *external configuration*, not hard-coded universal user fees.
5. Mixed account snapshots and event-window execution rows must be rejected as mismatched populations.
6. One-day 29-position snapshot never yields a claimed prospective ROI, Sharpe significance or model-promotion eligibility.
7. Maker price touch without executable queue/order-book evidence cannot be counted as filled.
8. Funding direction and funding-event timestamp correctly applied; no assumed universal 8h cadence.
9. Rejected signal replay is absent/not authorized. No fabricated shadow executions.
10. QIM disabled/no independent source -> no invented independent quote confirmation.
11. All eight account IDs, balances and histories unchanged in isolated regression scenario, with protected existing-account fixtures.
12. Unchanged champion paper positions, risk caps, strategies and accepted promotion policy; no live trading APIs.
13. Read-only API is authenticated, scoped, paginated, rate-limited and bounded, with NULL reasons and truthful empty states.
14. Actual full PHPUnit, Pint, Vue tests/typecheck/build, Go tests if relevant, and nonmutating smoke audit; do not fabricate command results.
15. Deliberately wrong-sign funding and double-subtracted slippage mutations must fail negative control tests.
16. Source snapshot integrity/hashes and independent re-run give identical outputs for the same immutable cohort.

## 6. Scope and delivery governance

- **First implement G0**, then only missing portions of previously approved read-only PROFIT-1 work (G1). The operator must expressly approve any new G2 experimental executor, new strategy policy or G4 commercial outreach before such actions. G3 reporting can be built read-only after G1. Do not presume the entire backlog is authorized by this spec.
- Existing `reports/profitability/P0_baseline.md` is referenced and reused as-is; it is **not** duplicated or moved (correction (e)). New phase reports go under `reports/profit-growth/`: `00-capability-and-data-inventory.md`, `01-cost-ledger-and-net-metrics.md`, `02-execution-experiments.md` (if approved), `03-robustness-and-portfolio.md`, `04-commercial-validation.md` (if approved), `05-verification.md`.
- Every report: exact window, SHA/source, ledger population, dependencies, source snapshots, query version, time zone, limitations, command, exit code, evidence hashes, negative controls and next approval needed.
- Feature flags OFF by default for any new scheduled collectors or experimental jobs. Retention/resource cost bounded. Fail closed when costs, authenticity or samples are unverified.
- Keep code narrowly scoped. Avoid rebuilding profit dashboards already present; reuse existing research/metric endpoints.
- No production deployment, new production migration, commit/push, real orders, account mutations, or ECONOM changes.

## 7. Codex execution directive

> Inspect the real repository and prior PROFIT-1 deliverables first. Implement G0 and the missing, previously authorized read-only G1 capability. Do not merely write another plan. Run tests and produce authentic evidence. Report `VERIFIED`, `FAILED`, `BLOCKED`, `NOT_EVALUATED` for each requirement. Propose the optional G2, G3 and G4 work as separately scoped changes where necessary; do not silently authorize rejected-signal replay, paper-strategy changes, external paid outreach, or live trading. Stop at any real authorization/safety boundary, while finishing all independent safe work.

## 8. Primary external evidence

- Official Bybit VIP Benefits / derivatives fee baseline (updated 2026-10-12): https://www.bybit.com/en/help-center/article/Benefits-of-the-VIP-Program
- Official Bybit Funding Fee Calculation (updated 2026-05-12): https://www.bybit.com/en/help-center/article/Funding-fee-calculation
- Historical source data: `vector-audit-1d-e534ac49-60de-5263-9685-4bea563094c2.zip` and `vector-audit-1d-53d90c98-a643-5bd0-8b5b-d3f90bdf7757.zip` (both in repository root; checksums recorded in `reports/profit-growth/00-capability-and-data-inventory.md` §1; authoritative archive confirmed by operator at G0).
- Existing local project spec: `VECTOR_PROFIT_1_Revision_2_1_Full_Spec.md` (scope and gates to honor, not automatically a declaration of implementation).
