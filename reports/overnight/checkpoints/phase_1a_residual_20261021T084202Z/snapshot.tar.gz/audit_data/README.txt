VECTOR Quant Research audit
UTC boundaries: [from, to). No order execution occurs.
Monetary amounts are decimal strings; drawdown values are percentage points.
Strategy decisions are not executed fills. Closed-trade PnL differs from equity when positions are open.
CSV values beginning with spreadsheet formula markers are escaped.
This package is a bounded best-effort extract, not a transactionally frozen snapshot.
No backtest data is mixed with forward-paper data.
