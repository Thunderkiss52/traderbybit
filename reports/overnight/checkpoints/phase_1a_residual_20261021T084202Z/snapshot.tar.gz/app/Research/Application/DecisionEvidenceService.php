<?php

declare(strict_types=1);

namespace App\Research\Application;

use App\Research\Domain\ResearchGenerationRecord;
use App\Research\Exceptions\IdempotencyConflictException;
use Carbon\CarbonImmutable;
use Ramsey\Uuid\Uuid;

final class DecisionEvidenceService
{
    public const METRIC_SCHEMA_VERSION = '1.0.0';

    public const ALGORITHM_VERSION = '1.0.0';

    /**
     * @param  array<string, mixed>  $parameters
     *
     * @throws IdempotencyConflictException
     */
    public function generate(array $parameters = []): ResearchGenerationRecord
    {
        $idempotencyKey = (string) ($parameters['idempotency_key'] ?? Uuid::uuid4()->toString());
        $accountingScope = (string) ($parameters['accounting_scope'] ?? 'FULL_LIFECYCLE');
        $asOf = isset($parameters['as_of']) ? CarbonImmutable::parse($parameters['as_of'], 'UTC') : CarbonImmutable::now('UTC');

        $normalizedParams = [
            'package_code' => 'P-6',
            'accounting_scope' => $accountingScope,
            'as_of' => $asOf->toIso8601String(),
            'algorithm_version' => self::ALGORITHM_VERSION,
        ];
        $payloadHash = hash('sha256', json_encode($normalizedParams, JSON_THROW_ON_ERROR));

        $existing = ResearchGenerationRecord::query()->where('idempotency_key', $idempotencyKey)->first();
        if ($existing !== null) {
            if ($existing->request_payload_hash !== $payloadHash) {
                throw new IdempotencyConflictException(
                    "Idempotency conflict: Key [{$idempotencyKey}] was previously used with a different request payload."
                );
            }

            return $existing;
        }

        $generationId = Uuid::uuid4()->toString();
        $generation = ResearchGenerationRecord::query()->create([
            'id' => $generationId,
            'package_code' => 'P-6',
            'accounting_scope' => $accountingScope,
            'as_of' => $asOf,
            'status' => 'RUNNING',
            'idempotency_key' => $idempotencyKey,
            'request_payload_hash' => $payloadHash,
            'versioned_config' => [
                'algorithm_version' => self::ALGORITHM_VERSION,
                'metric_schema_version' => self::METRIC_SCHEMA_VERSION,
            ],
            'heartbeat_at' => CarbonImmutable::now('UTC'),
            'stale_after_seconds' => 300,
        ]);

        try {
            $outputHash = hash('sha256', $generationId);
            $generation->update([
                'status' => 'SUCCEEDED',
                'output_hash' => $outputHash,
                'row_counts' => ['records' => 0],
                'metadata' => ['note' => 'Research-only stub (P-3 replay PROHIBITED).'],
                'heartbeat_at' => CarbonImmutable::now('UTC'),
            ]);

            return $generation->refresh();
        } catch (\Throwable $e) {
            $generation->update([
                'status' => 'FAILED',
                'error_message' => $e->getMessage(),
                'heartbeat_at' => CarbonImmutable::now('UTC'),
            ]);
            throw $e;
        }
    }
}
