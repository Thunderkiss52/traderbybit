<?php

declare(strict_types=1);

namespace App\Research\Application;

use App\PaperTrading\Application\PaperAccountService;
use App\PaperTrading\Infrastructure\Persistence\EquitySnapshotRecord;
use App\PaperTrading\Infrastructure\Persistence\PaperAccountRecord;
use App\PaperTrading\Infrastructure\Persistence\VirtualExecutionRecord;
use App\PaperTrading\Infrastructure\Persistence\VirtualPositionRecord;
use App\Research\Domain\ResearchGenerationRecord;
use App\Research\Domain\SlippageAttributionRecord;
use App\Research\Domain\StrategyRiskMetricRecord;
use App\Research\Exceptions\IdempotencyConflictException;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;
use Carbon\CarbonImmutable;
use Ramsey\Uuid\Uuid;

final class RiskCapitalMetricsService
{
    public const METRIC_SCHEMA_VERSION = '1.0.0';

    public const ALGORITHM_VERSION = '1.0.0';

    public const DEFAULT_MAX_CARRY_FORWARD_AGE_SECONDS = 86400; // 24 hours

    public function __construct(
        private readonly PaperAccountService $accountService,
    ) {}

    /**
     * Compute and store immutable research generation of P-2 risk and capital-efficiency metrics.
     *
     * @param  array<string, mixed>  $parameters
     *
     * @throws IdempotencyConflictException
     */
    public function generate(array $parameters = []): ResearchGenerationRecord
    {
        $idempotencyKey = (string) ($parameters['idempotency_key'] ?? Uuid::uuid4()->toString());
        $accountingScope = (string) ($parameters['accounting_scope'] ?? 'FULL_LIFECYCLE');
        $asOf = isset($parameters['as_of'])
            ? CarbonImmutable::parse($parameters['as_of'], 'UTC')
            : CarbonImmutable::now('UTC');
        $symbol = (string) ($parameters['symbol'] ?? 'ALL');
        $maxCarryForwardAge = (int) ($parameters['max_carry_forward_age_seconds'] ?? self::DEFAULT_MAX_CARRY_FORWARD_AGE_SECONDS);

        $windowStart = isset($parameters['window_start']) ? CarbonImmutable::parse($parameters['window_start'], 'UTC') : null;
        $windowEnd = isset($parameters['window_end']) ? CarbonImmutable::parse($parameters['window_end'], 'UTC') : null;

        $normalizedParams = [
            'package_code' => 'P-2',
            'accounting_scope' => $accountingScope,
            'as_of' => $asOf->toIso8601String(),
            'symbol' => $symbol,
            'window_start' => $windowStart?->toIso8601String(),
            'window_end' => $windowEnd?->toIso8601String(),
            'max_carry_forward_age_seconds' => $maxCarryForwardAge,
            'algorithm_version' => self::ALGORITHM_VERSION,
        ];
        $payloadHash = hash('sha256', json_encode($normalizedParams, JSON_THROW_ON_ERROR));

        // Idempotency check
        $existing = ResearchGenerationRecord::query()->where('idempotency_key', $idempotencyKey)->first();
        if ($existing !== null) {
            if ($existing->request_payload_hash !== $payloadHash) {
                throw new IdempotencyConflictException(
                    "Idempotency conflict: Key [{$idempotencyKey}] was previously used with a different request payload."
                );
            }

            return $existing;
        }

        $generationId = Uuid::uuid4()->toString();
        $generation = ResearchGenerationRecord::query()->create([
            'id' => $generationId,
            'package_code' => 'P-2',
            'accounting_scope' => $accountingScope,
            'as_of' => $asOf,
            'status' => 'RUNNING',
            'idempotency_key' => $idempotencyKey,
            'request_payload_hash' => $payloadHash,
            'versioned_config' => [
                'algorithm_version' => self::ALGORITHM_VERSION,
                'metric_schema_version' => self::METRIC_SCHEMA_VERSION,
                'max_carry_forward_age_seconds' => $maxCarryForwardAge,
                'epsilon' => '1e-8',
                'min_days_sample_sufficiency' => 20,
                'min_ess_sample_sufficiency' => 20,
            ],
            'heartbeat_at' => CarbonImmutable::now('UTC'),
            'stale_after_seconds' => 300,
        ]);

        try {
            $accounts = $this->accountService->allPrimaryAccounts();
            $recordsToInsert = [];

            foreach ($accounts as $account) {
                $metric = $this->computeForAccount(
                    $account,
                    $generationId,
                    $accountingScope,
                    $asOf,
                    $symbol,
                    $windowStart,
                    $windowEnd,
                    $maxCarryForwardAge
                );

                $recordsToInsert[] = $metric;
            }

            foreach (array_chunk($recordsToInsert, 50) as $chunk) {
                StrategyRiskMetricRecord::query()->insert($chunk);
            }

            $outputHash = hash('sha256', json_encode([
                'generation_id' => $generationId,
                'records_count' => count($recordsToInsert),
                'account_ids' => $accounts->pluck('id')->sort()->values()->all(),
            ], JSON_THROW_ON_ERROR));

            $generation->update([
                'status' => 'SUCCEEDED',
                'output_hash' => $outputHash,
                'row_counts' => [
                    'strategy_risk_metrics' => count($recordsToInsert),
                ],
                'metadata' => [
                    'accounts_processed' => count($accounts),
                ],
                'heartbeat_at' => CarbonImmutable::now('UTC'),
            ]);

            return $generation->refresh();
        } catch (\Throwable $e) {
            $generation->update([
                'status' => 'FAILED',
                'error_message' => $e->getMessage(),
                'heartbeat_at' => CarbonImmutable::now('UTC'),
            ]);

            throw $e;
        }
    }

    /**
     * Compute P-2 risk metrics for a single independent paper account.
     *
     * @return array<string, mixed>
     */
    public function computeForAccount(
        PaperAccountRecord $account,
        string $generationId,
        string $accountingScope,
        CarbonImmutable $asOf,
        string $symbol,
        ?CarbonImmutable $windowStart,
        ?CarbonImmutable $windowEnd,
        int $maxCarryForwardAge
    ): array {
        $strategyId = (string) ($account->strategy_id ?? $account->name ?? 'unknown');

        // Query positions
        $positionsQuery = VirtualPositionRecord::query()->where('paper_account_id', $account->id);
        if ($symbol !== 'ALL') {
            $positionsQuery->where('symbol', $symbol);
        }
        if ($accountingScope === 'WINDOW_FLOW' && $windowStart !== null && $windowEnd !== null) {
            $positionsQuery->where('opened_at', '>=', $windowStart)->where('opened_at', '<', $windowEnd);
        }
        $positions = $positionsQuery->get();

        $nPositions = count($positions);
        $nWins = 0;
        $nLosses = 0;
        $nFlat = 0;
        $exclusionsCount = 0;
        $epsilon = BigDecimal::of('0.00000001');

        $netRList = [];
        $grossGains = BigDecimal::zero();
        $grossLosses = BigDecimal::zero();
        $winNetPnls = [];
        $lossNetPnls = [];

        $totalRealizedNetPnl = BigDecimal::zero();
        $totalInitialRiskCapital = BigDecimal::zero();
        $totalEntryNotional = BigDecimal::zero();

        $dailyRealizedNetPnl = [];
        $dailyRiskCapitalExited = [];

        foreach ($positions as $pos) {
            $netPnl = BigDecimal::of($pos->net_pnl ?? '0');
            $riskCapital = BigDecimal::of($pos->risk_capital ?? '0');
            $entryPrice = BigDecimal::of($pos->entry_price ?? '0');
            $initQty = BigDecimal::of($pos->initial_quantity ?? '0');
            $entryNotional = $entryPrice->multipliedBy($initQty);
            $totalEntryNotional = $totalEntryNotional->plus($entryNotional);

            // Win / Loss / Flat classification
            if ($netPnl->isGreaterThan($epsilon)) {
                $nWins++;
                $grossGains = $grossGains->plus($netPnl);
                $winNetPnls[] = $netPnl;
            } elseif ($netPnl->isLessThan($epsilon->negated())) {
                $nLosses++;
                $grossLosses = $grossLosses->plus($netPnl->abs());
                $lossNetPnls[] = $netPnl->abs();
            } else {
                $nFlat++;
            }

            $totalRealizedNetPnl = $totalRealizedNetPnl->plus($netPnl);

            // Position R calculation
            if ($riskCapital->isGreaterThan(BigDecimal::zero())) {
                $r = $netPnl->dividedBy($riskCapital, 8, RoundingMode::HalfEven);
                $netRList[] = $r;
                $totalInitialRiskCapital = $totalInitialRiskCapital->plus($riskCapital);
            } else {
                $exclusionsCount++;
            }

            // Daily attribution (booked on closed_at or opened_at)
            $eventAt = $pos->closed_at ?? $pos->opened_at;
            if ($eventAt !== null) {
                $dateKey = CarbonImmutable::parse($eventAt, 'UTC')->toDateString();
                if (! isset($dailyRealizedNetPnl[$dateKey])) {
                    $dailyRealizedNetPnl[$dateKey] = BigDecimal::zero();
                    $dailyRiskCapitalExited[$dateKey] = BigDecimal::zero();
                }
                $dailyRealizedNetPnl[$dateKey] = $dailyRealizedNetPnl[$dateKey]->plus($netPnl);
                if ($riskCapital->isGreaterThan(BigDecimal::zero())) {
                    $dailyRiskCapitalExited[$dateKey] = $dailyRiskCapitalExited[$dateKey]->plus($riskCapital);
                }
            }
        }

        // Mean & Median Net R
        $netRMean = null;
        $netRMedian = null;
        if (count($netRList) > 0) {
            $sumR = BigDecimal::zero();
            foreach ($netRList as $rVal) {
                $sumR = $sumR->plus($rVal);
            }
            $netRMean = (string) $sumR->dividedBy(count($netRList), 8, RoundingMode::HalfEven);

            sort($netRList);
            $count = count($netRList);
            $mid = (int) floor($count / 2);
            if ($count % 2 === 1) {
                $netRMedian = (string) $netRList[$mid];
            } else {
                $netRMedian = (string) $netRList[$mid - 1]->plus($netRList[$mid])->dividedBy(2, 8, RoundingMode::HalfEven);
            }
        }

        // Profit Factor
        $profitFactor = null;
        $profitFactorReason = null;
        if ($grossLosses->isZero()) {
            $profitFactorReason = 'UNDEFINED_NO_LOSSES';
        } else {
            $profitFactor = (string) $grossGains->dividedBy($grossLosses, 8, RoundingMode::HalfEven);
        }

        // Win Rate
        $winRate = null;
        $winLossTotal = $nWins + $nLosses;
        if ($winLossTotal > 0) {
            $winRate = (string) BigDecimal::of($nWins)->dividedBy($winLossTotal, 6, RoundingMode::HalfEven);
        }

        // Payoff Ratio
        $payoffRatio = null;
        if (count($winNetPnls) > 0 && count($lossNetPnls) > 0) {
            $meanWin = array_sum(array_map('floatval', $winNetPnls)) / count($winNetPnls);
            $meanLoss = array_sum(array_map('floatval', $lossNetPnls)) / count($lossNetPnls);
            if ($meanLoss > 0) {
                $payoffRatio = (string) BigDecimal::of((string) $meanWin)->dividedBy((string) $meanLoss, 8, RoundingMode::HalfEven);
            }
        }

        // Cost-to-risk ratio using matched P-1 slippage drag
        $costToRiskRatio = null;
        if ($totalInitialRiskCapital->isGreaterThan(BigDecimal::zero())) {
            $posIds = $positions->pluck('id')->all();
            $slippageAttributions = SlippageAttributionRecord::query()
                ->whereIn('position_id', $posIds)
                ->get();

            $totalSlippageDrag = BigDecimal::zero();
            foreach ($slippageAttributions as $sa) {
                $totalSlippageDrag = $totalSlippageDrag->plus(BigDecimal::of($sa->total_slippage_drag_usdt));
            }

            $totalFees = BigDecimal::zero();
            $totalSignedFunding = BigDecimal::zero();
            foreach ($positions as $p) {
                $totalFees = $totalFees->plus(BigDecimal::of($p->fees ?? '0'));
                $totalSignedFunding = $totalSignedFunding->plus(BigDecimal::of($p->funding ?? '0'));
            }

            // cost_to_risk = (fees + slippage_drag - funding) / initial_risk_capital
            $totalFriction = $totalFees->plus($totalSlippageDrag)->minus($totalSignedFunding);
            $costToRiskRatio = (string) $totalFriction->dividedBy($totalInitialRiskCapital, 8, RoundingMode::HalfEven);
        }

        // Equity series, Max Drawdown, Time Underwater, TWAE
        $startingEquity = BigDecimal::of((string) ($account->starting_balance ?? '10000.00'));
        $equitySnapshotsQuery = EquitySnapshotRecord::query()
            ->where('paper_account_id', $account->id)
            ->orderBy('recorded_at');

        if ($accountingScope === 'WINDOW_FLOW' && $windowStart !== null && $windowEnd !== null) {
            $equitySnapshotsQuery->where('recorded_at', '>=', $windowStart)->where('recorded_at', '<', $windowEnd);
        }
        $equitySnapshots = $equitySnapshotsQuery->get();

        $runningPeak = $startingEquity;
        $maxDrawdown = BigDecimal::zero();
        $totalValidObservationSeconds = 0;
        $totalUnderwaterSeconds = 0;
        $twaeNumerator = BigDecimal::zero();
        $twaeDenominator = 0;
        $coverageGapSeconds = 0;

        $snapshotCount = count($equitySnapshots);
        for ($i = 0; $i < $snapshotCount; $i++) {
            $curr = $equitySnapshots[$i];
            $currEquity = BigDecimal::of((string) $curr->equity);
            $currTime = CarbonImmutable::parse($curr->recorded_at, 'UTC');

            if ($currEquity->isGreaterThan($runningPeak)) {
                $runningPeak = $currEquity;
            }

            if (! $runningPeak->isZero()) {
                $dd = $runningPeak->minus($currEquity)->dividedBy($runningPeak, 12, RoundingMode::HalfEven)->multipliedBy(100);
                if ($dd->isGreaterThan($maxDrawdown)) {
                    $maxDrawdown = $dd;
                }
            }

            if ($i < $snapshotCount - 1) {
                $next = $equitySnapshots[$i + 1];
                $nextTime = CarbonImmutable::parse($next->recorded_at, 'UTC');
                $deltaSec = max(0, $nextTime->getTimestamp() - $currTime->getTimestamp());

                $validDelta = min($deltaSec, $maxCarryForwardAge);
                $gap = max(0, $deltaSec - $maxCarryForwardAge);
                $coverageGapSeconds += $gap;

                $totalValidObservationSeconds += $validDelta;
                $twaeNumerator = $twaeNumerator->plus($currEquity->multipliedBy($validDelta));
                $twaeDenominator += $validDelta;

                if ($currEquity->isLessThan($runningPeak)) {
                    $totalUnderwaterSeconds += $validDelta;
                }
            }
        }

        $maxDrawdownPct = (string) $maxDrawdown->toScale(6, RoundingMode::HalfEven);
        $timeUnderwaterPct = $totalValidObservationSeconds > 0
            ? (string) BigDecimal::of($totalUnderwaterSeconds)->dividedBy($totalValidObservationSeconds, 8, RoundingMode::HalfEven)->multipliedBy(100)->toScale(4, RoundingMode::HalfEven)
            : '0.0000';

        $twaEquity = $twaeDenominator > 0
            ? (string) $twaeNumerator->dividedBy($twaeDenominator, 8, RoundingMode::HalfEven)
            : (string) $startingEquity;

        // Turnover & Capital Efficiency
        $turnover = null;
        $netReturnOnEquity = null;
        $twaeBd = BigDecimal::of($twaEquity);

        if ($twaeBd->isGreaterThan(BigDecimal::zero())) {
            // Turnover: sum of fill notional / TWAE
            $fillsNotional = BigDecimal::zero();
            $executions = VirtualExecutionRecord::query()
                ->whereIn('position_id', $positions->pluck('id'))
                ->get();

            foreach ($executions as $exec) {
                $p = BigDecimal::of((string) $exec->price);
                $q = BigDecimal::of((string) $exec->quantity);
                $fillsNotional = $fillsNotional->plus($p->multipliedBy($q));
            }

            $turnover = (string) $fillsNotional->dividedBy($twaeBd, 8, RoundingMode::HalfEven);
            $netReturnOnEquity = (string) $totalRealizedNetPnl->dividedBy($twaeBd, 8, RoundingMode::HalfEven);
        }

        $netPnlPerRiskCapital = $totalInitialRiskCapital->isGreaterThan(BigDecimal::zero())
            ? (string) $totalRealizedNetPnl->dividedBy($totalInitialRiskCapital, 8, RoundingMode::HalfEven)
            : null;

        $notionalPerInitialRisk = $totalInitialRiskCapital->isGreaterThan(BigDecimal::zero())
            ? (string) $totalEntryNotional->dividedBy($totalInitialRiskCapital, 8, RoundingMode::HalfEven)
            : null;

        // Daily realized Net R series & ESS calculation
        $nDays = count($dailyRealizedNetPnl);
        $dailyRSeries = [];
        foreach ($dailyRealizedNetPnl as $dKey => $dayNetPnl) {
            $dayRisk = $dailyRiskCapitalExited[$dKey] ?? BigDecimal::zero();
            if ($dayRisk->isGreaterThan(BigDecimal::zero())) {
                $dailyRSeries[] = (float) (string) $dayNetPnl->dividedBy($dayRisk, 8, RoundingMode::HalfEven);
            } else {
                $dailyRSeries[] = (float) (string) $dayNetPnl;
            }
        }

        [$ess, $essClamped] = $this->calculateBartlettEss($dailyRSeries);

        // Sample sufficiency evaluation
        $sufficiencyReasons = [];
        if ($nDays < 20) {
            $sufficiencyReasons[] = "INSUFFICIENT_CALENDAR_DAYS: Expected >= 20 non-overlapping UTC days, observed [{$nDays}].";
        }
        if ($ess === null || $ess < 20.0) {
            $sufficiencyReasons[] = 'ESS_BELOW_MINIMUM_20: Effective sample size ['.($ess ?? 'NULL').'] is below the normative threshold of 20.';
        }
        $totalSpan = $totalValidObservationSeconds + $coverageGapSeconds;
        if ($totalSpan > 0 && ($coverageGapSeconds / $totalSpan) > 0.20) {
            $sufficiencyReasons[] = 'EXCESSIVE_EQUITY_COVERAGE_GAPS: Coverage gap seconds ['.$coverageGapSeconds.'] exceeds 20% of observation window.';
        }

        $sampleSufficiency = empty($sufficiencyReasons) ? 'SUFFICIENT' : 'INSUFFICIENT_DATA';

        $dimStart = $windowStart?->toIso8601String() ?? 'NONE';
        $dimEnd = $windowEnd?->toIso8601String() ?? 'NONE';
        $dimensionKey = hash('sha256', "{$account->id}|{$strategyId}|{$symbol}|{$accountingScope}|{$dimStart}|{$dimEnd}");

        return [
            'id' => Uuid::uuid4()->toString(),
            'generation_id' => $generationId,
            'dimension_key' => $dimensionKey,
            'paper_account_id' => $account->id,
            'strategy_id' => $strategyId,
            'symbol' => $symbol,
            'accounting_scope' => $accountingScope,
            'as_of' => $asOf,
            'window_start' => $windowStart,
            'window_end' => $windowEnd,
            'metric_schema_version' => self::METRIC_SCHEMA_VERSION,
            'n_positions' => $nPositions,
            'n_wins' => $nWins,
            'n_losses' => $nLosses,
            'n_flat' => $nFlat,
            'n_days' => $nDays,
            'exclusions_count' => $exclusionsCount,
            'net_r_mean' => $netRMean,
            'net_r_median' => $netRMedian,
            'cost_to_risk_ratio' => $costToRiskRatio,
            'profit_factor' => $profitFactor,
            'profit_factor_reason' => $profitFactorReason,
            'win_rate' => $winRate,
            'payoff_ratio' => $payoffRatio,
            'max_drawdown_pct' => $maxDrawdownPct,
            'time_underwater_pct' => $timeUnderwaterPct,
            'twa_equity' => $twaEquity,
            'max_carry_forward_age_seconds' => $maxCarryForwardAge,
            'coverage_gap_seconds' => $coverageGapSeconds,
            'turnover' => $turnover,
            'net_return_on_equity' => $netReturnOnEquity,
            'net_pnl_per_risk_capital' => $netPnlPerRiskCapital,
            'average_gross_notional_exposure_pct' => null,
            'average_open_risk_capital_pct' => null,
            'time_with_open_exposure_pct' => null,
            'notional_per_initial_risk_capital' => $notionalPerInitialRisk,
            'average_margin_used_pct_of_equity' => null,
            'average_margin_reason' => 'NOT_RECORDED_IN_LEDGER',
            'sharpe_like' => null,
            'ess' => $ess !== null ? (string) round($ess, 4) : null,
            'ess_clamped' => $essClamped,
            'ess_method' => 'BARTLETT_AUTOCORRELATION_LAG_FLOOR_N_DIV_4',
            'sample_sufficiency' => $sampleSufficiency,
            'sample_sufficiency_reasons' => $sufficiencyReasons,
            'provenance' => 'RECOMPUTED_FROM_SOURCE',
            'created_at' => CarbonImmutable::now('UTC'),
            'updated_at' => CarbonImmutable::now('UTC'),
        ];
    }

    /**
     * Calculate Bartlett-style Effective Sample Size on a discrete series:
     * ESS = n / (1 + 2 * sum(rho_k, k=1..K)) where K = floor(n / 4).
     *
     * @param  array<int, float>  $series
     * @return array{0: float|null, 1: bool} [ess, clamped]
     */
    public function calculateBartlettEss(array $series): array
    {
        $n = count($series);
        if ($n < 4) {
            return [$n > 0 ? (float) $n : null, false];
        }

        $mean = array_sum($series) / $n;
        $variance = 0.0;
        foreach ($series as $val) {
            $variance += ($val - $mean) ** 2;
        }

        if ($variance <= 1e-12) {
            return [1.0, true];
        }

        $kMax = (int) floor($n / 4);
        $rhoSum = 0.0;

        for ($k = 1; $k <= $kMax; $k++) {
            $covK = 0.0;
            for ($t = 0; $t < $n - $k; $t++) {
                $covK += ($series[$t] - $mean) * ($series[$t + $k] - $mean);
            }
            $rhoK = $covK / $variance;
            $rhoSum += $rhoK;
        }

        $denom = 1.0 + 2.0 * $rhoSum;
        if ($denom <= 0.0) {
            return [1.0, true];
        }

        $rawEss = $n / $denom;
        if ($rawEss > $n) {
            return [(float) $n, true];
        }
        if ($rawEss < 1.0) {
            return [1.0, true];
        }

        return [$rawEss, false];
    }

    /**
     * Retrieve the latest succeeded P-2 risk metrics per strategy.
     * Purely read-only; zero database writes.
     *
     * @return array<string, mixed>
     */
    public function getLatestMetrics(string $accountingScope = 'FULL_LIFECYCLE'): array
    {
        $generation = ResearchGenerationRecord::query()
            ->where('package_code', 'P-2')
            ->where('status', 'SUCCEEDED')
            ->where('accounting_scope', $accountingScope)
            ->latest('created_at')
            ->first();

        if ($generation === null) {
            return [
                'status' => 'NO_GENERATION_AVAILABLE',
                'message' => 'No completed P-2 research generation exists yet for scope: '.$accountingScope,
                'provenance' => 'INSUFFICIENT_DATA',
            ];
        }

        $metrics = StrategyRiskMetricRecord::query()
            ->where('generation_id', $generation->id)
            ->get();

        return [
            'status' => 'SUCCEEDED',
            'generation_id' => $generation->id,
            'accounting_scope' => $generation->accounting_scope,
            'as_of' => $generation->as_of?->toIso8601String(),
            'output_hash' => $generation->output_hash,
            'metric_schema_version' => self::METRIC_SCHEMA_VERSION,
            'algorithm_version' => self::ALGORITHM_VERSION,
            'metrics' => $metrics,
        ];
    }
}
