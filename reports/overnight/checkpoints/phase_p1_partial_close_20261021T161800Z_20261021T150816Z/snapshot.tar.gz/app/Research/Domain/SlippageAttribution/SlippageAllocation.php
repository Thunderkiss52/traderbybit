<?php

declare(strict_types=1);

namespace App\Research\Domain\SlippageAttribution;

use Brick\Math\BigDecimal;
use Brick\Math\Exception\MathException;
use Brick\Math\RoundingMode;

/**
 * PROFIT-1 / P-1 — realized-scope slippage allocation (§7, partial-close sanity).
 *
 * The full-fill execution population and the realized counterfactual are two
 * different populations and must never be mixed:
 *
 *  - a fully closed position realizes its whole slippage drag;
 *  - a partially closed position realizes the entry drag proportionally to the
 *    closed volume and realizes its exit drag in full (exits only ever close
 *    volume);
 *  - a still open position realizes no entry drag at all, because the entry
 *    slippage is embedded in the entry price and therefore lives in the
 *    unrealized PnL, not in the realized net PnL.
 *
 * The realized-scope counterfactual is therefore
 *     realized_scope_net_pnl + realized_allocated_slippage_drag
 * and the full-fill figure is reported separately with an explicit
 * NOT_VERIFIED_SCOPE_MISMATCH status. Slippage is never deducted twice: it is
 * an attribution of the realized drag, never a second cost.
 */
final class SlippageAllocation
{
    public const STATUS_COMPUTED = 'COMPUTED';

    public const STATUS_COMPUTED_RECONCILED = 'COMPUTED_RECONCILED';

    public const STATUS_INSUFFICIENT_DATA = 'INSUFFICIENT_DATA';

    public const RAW_STATUS_COMPUTED = 'COMPUTED';

    public const RAW_STATUS_NOT_VERIFIED_SCOPE_MISMATCH = 'NOT_VERIFIED_SCOPE_MISMATCH';

    public const RAW_STATUS_INSUFFICIENT_DATA = 'INSUFFICIENT_DATA';

    private const SCALE = 12;

    /**
     * @param  list<array{position_id:string,initial_quantity:string,remaining_quantity:string,net_pnl:string,entry_slippage_usdt:string,exit_slippage_usdt:string}>  $positions
     * @param  int  $expectedPopulationSize  number of positions the caller expects to reconcile against.
     * @return array<string, mixed>
     */
    public function allocate(array $positions, int $expectedPopulationSize): array
    {
        $populationMatch = $expectedPopulationSize > 0 && count($positions) === $expectedPopulationSize;

        $realizedNetPnl = BigDecimal::zero();
        $realizedDrag = BigDecimal::zero();
        $openDrag = BigDecimal::zero();
        $fullFillDrag = BigDecimal::zero();
        $openNetPnl = BigDecimal::zero();

        $closedCount = 0;
        $partialCount = 0;
        $openCount = 0;
        $invalidCount = 0;

        foreach ($positions as $position) {
            $initial = BigDecimal::of((string) $position['initial_quantity']);
            $remaining = BigDecimal::of((string) $position['remaining_quantity']);
            $netPnl = BigDecimal::of((string) $position['net_pnl']);
            $entryDrag = BigDecimal::of((string) $position['entry_slippage_usdt']);
            $exitDrag = BigDecimal::of((string) $position['exit_slippage_usdt']);

            $fullFillDrag = $fullFillDrag->plus($entryDrag)->plus($exitDrag);

            if ($initial->isLessThanOrEqualTo(BigDecimal::zero()) || $remaining->isGreaterThan($initial)) {
                $invalidCount++;

                continue;
            }

            $closedQuantity = $initial->minus($remaining);

            if ($closedQuantity->isZero()) {
                // Still open: the entry slippage is unrealized, the exit drag is zero by construction.
                $openCount++;
                $openNetPnl = $openNetPnl->plus($netPnl);
                $openDrag = $openDrag->plus($entryDrag)->plus($exitDrag);

                continue;
            }

            $closedFraction = $closedQuantity->dividedBy($initial, self::SCALE, RoundingMode::HalfEven);
            $openFraction = BigDecimal::one()->minus($closedFraction);

            $realizedNetPnl = $realizedNetPnl->plus($netPnl);
            $realizedDrag = $realizedDrag
                ->plus($entryDrag->multipliedBy($closedFraction))
                ->plus($exitDrag);
            $openDrag = $openDrag->plus($entryDrag->multipliedBy($openFraction));

            if ($remaining->isZero()) {
                $closedCount++;
            } else {
                $partialCount++;
            }
        }

        $hasScopeMismatch = $partialCount > 0 || $openCount > 0;

        $status = match (true) {
            ! $populationMatch || $invalidCount > 0 => self::STATUS_INSUFFICIENT_DATA,
            $partialCount > 0 => self::STATUS_COMPUTED_RECONCILED,
            default => self::STATUS_COMPUTED,
        };

        $rawStatus = match (true) {
            ! $populationMatch || $invalidCount > 0 => self::RAW_STATUS_INSUFFICIENT_DATA,
            $hasScopeMismatch => self::RAW_STATUS_NOT_VERIFIED_SCOPE_MISMATCH,
            default => self::RAW_STATUS_COMPUTED,
        };

        $note = match (true) {
            ! $populationMatch => 'Population reconciliation failed: the attributed positions do not match the expected population. The counterfactual is NOT_VERIFIED.',
            $invalidCount > 0 => 'Position quantities are inconsistent (non-positive initial quantity or remaining quantity above the initial quantity). The counterfactual is NOT_VERIFIED.',
            $partialCount > 0 => 'Entry slippage of partially closed positions is allocated proportionally to the realized closed volume; the open remainder stays in the unallocated bucket.',
            $openCount > 0 => 'Entry slippage of still open positions is unrealized and is excluded from the realized counterfactual; the full-fill figure is reported separately as NOT_VERIFIED_SCOPE_MISMATCH.',
            default => 'All positions are fully closed: the realized drag equals the total full-fill execution drag.',
        };

        return [
            'status' => $status,
            'provenance' => $status === self::STATUS_INSUFFICIENT_DATA ? 'NOT_VERIFIED' : 'HYPOTHETICAL',
            'population_match' => $populationMatch,
            'expected_population_size' => $expectedPopulationSize,
            'reconciled_population_size' => count($positions),
            'closed_position_count' => $closedCount,
            'partial_position_count' => $partialCount,
            'open_position_count' => $openCount,
            'invalid_position_count' => $invalidCount,
            'realized_scope_net_pnl' => $status === self::STATUS_INSUFFICIENT_DATA ? null : $this->normalize($realizedNetPnl),
            'open_position_net_pnl' => $this->normalize($openNetPnl),
            'realized_allocated_slippage_drag' => $status === self::STATUS_INSUFFICIENT_DATA ? null : $this->normalize($realizedDrag),
            'open_unallocated_slippage_drag' => $this->normalize($openDrag),
            'full_fill_slippage_drag' => $this->normalize($fullFillDrag),
            'raw_counterfactual_status' => $rawStatus,
            'reconciliation_note' => $note,
        ];
    }

    /**
     * Render an exact decimal without a trailing zero scale, so the emitted
     * values stay comparable with the rest of the research evidence.
     */
    private function normalize(BigDecimal $value): string
    {
        try {
            return (string) $value->toScale(0, RoundingMode::Unnecessary);
        } catch (MathException) {
            $rendered = (string) $value;

            if (! str_contains($rendered, '.')) {
                return $rendered;
            }

            $trimmed = rtrim(rtrim($rendered, '0'), '.');

            return $trimmed === '-0' ? '0' : $trimmed;
        }
    }
}
