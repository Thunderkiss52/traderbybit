# VECTOR — Full-System UI, API & Financial Reconciliation Audit Report

- **Execution Date:** 2026-11-10 10:57:51 UTC
- **Audit Mode:** `FULL`
- **Overall Result:** **PASSED**
- **Total Execution Time:** `36.66s`

---

## 1. Executive Summary

| Audit Domain | Scope / Targets | Passed | Warnings | Failed | Status |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Strategy Topology & Matrix** | 13 Strategies × 10 Exchanges | 130 pairs | 0 | 0 | **PASS** |
| **Browser UI Routes & Components** | 25 Routes | 25 | 0 | 0 | **PASS** |
| **API Pagination & Filter Contracts** | 7 Endpoints | 7 | 0 | 0 | **PASS** |
| **Financial & Ledger Reconciliation** | 130 Accounts | 130 | 0 | 0 | **PASS** |

---

## 2. Strategy Completeness & Lifecycle Matrix

- **Total Registered Strategies:** `13`
- **Registered Exchanges:** `10` (`bybit, binance, coinbase, upbit, okx, bitget, gate, kucoin, kraken, htx`)
- **Topology Grid:** `130 isolated virtual portfolios`
- **Active Execution Portfolios:** `13` (All Bybit primary accounts funded at 10,000 USDT)
- **Zero-Funded / Blocked Portfolios:** `117` (Preserved safety invariants for unapproved venues)

---

## 3. UI Route Navigation & Browser Runtime Health

| Route | Title | HTTP | Duration | Status | Notes |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `/dashboard` | Dashboard | 200 | 1452.33ms | **PASS** | Clean render, zero JS errors |
| `/market/BTCUSDT` | Market BTCUSDT | 200 | 1649.42ms | **PASS** | Clean render, zero JS errors |
| `/market/ETHUSDT` | Market ETHUSDT | 200 | 1143.01ms | **PASS** | Clean render, zero JS errors |
| `/signals` | Signals | 200 | 1107.56ms | **PASS** | Clean render, zero JS errors |
| `/monitor` | Strategy Signal Monitor | 200 | 1112.31ms | **PASS** | Clean render, zero JS errors |
| `/positions` | Positions | 200 | 1094.36ms | **PASS** | Clean render, zero JS errors |
| `/journal` | Journal | 200 | 1105.64ms | **PASS** | Clean render, zero JS errors |
| `/audit` | Audit | 200 | 1106.42ms | **PASS** | Clean render, zero JS errors |
| `/exchanges` | Exchanges | 200 | 1114.17ms | **PASS** | Clean render, zero JS errors |
| `/exchanges/binance/historical` | Binance Historical | 200 | 1113.17ms | **PASS** | Clean render, zero JS errors |
| `/statistics` | Statistics | 200 | 1109.4ms | **PASS** | Clean render, zero JS errors |
| `/research` | Research Lab | 200 | 1133.42ms | **PASS** | Clean render, zero JS errors |
| `/research/health` | Research Health | 200 | 1102.55ms | **PASS** | Clean render, zero JS errors |
| `/research/opportunities` | Opportunities | 200 | 1096.29ms | **PASS** | Clean render, zero JS errors |
| `/research/replay` | Decision Replay | 200 | 1092.96ms | **PASS** | Clean render, zero JS errors |
| `/research/calibration` | Calibration | 200 | 1099.86ms | **PASS** | Clean render, zero JS errors |
| `/research/intelligence` | Intelligence | 200 | 1089.84ms | **PASS** | Clean render, zero JS errors |
| `/research/learning` | Autonomous Learning | 200 | 1089.78ms | **PASS** | Clean render, zero JS errors |
| `/research/patterns` | Pattern Discovery | 200 | 1115.99ms | **PASS** | Clean render, zero JS errors |
| `/research/profitability` | Profitability Research | 200 | 1131.92ms | **PASS** | Clean render, zero JS errors |
| `/strategies` | Strategies Catalog | 200 | 1219.13ms | **PASS** | Clean render, zero JS errors |
| `/backtests` | Backtests | 200 | 1102.03ms | **PASS** | Clean render, zero JS errors |
| `/risk` | Risk Management | 200 | 1129.35ms | **PASS** | Clean render, zero JS errors |
| `/quote-integrity` | Quote Integrity | 200 | 1113.93ms | **PASS** | Clean render, zero JS errors |
| `/settings` | Settings | 200 | 1125.97ms | **PASS** | Clean render, zero JS errors |

---

## 4. API Pagination & Dataset Integrity

| Endpoint | Dataset | Page 1 | Page 2 | Overlapping IDs | Out of Bounds (9999) | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| `/signals` | signals | 0 items | 0 items | 0 | HTTP 200 (0 items) | **PASS** |
| `/positions` | positions | 0 items | 0 items | 0 | HTTP 200 (0 items) | **PASS** |
| `/journal` | journal | 0 items | 0 items | 0 | HTTP 200 (0 items) | **PASS** |
| `/audit/exports` | audit_exports | 0 items | 0 items | 0 | HTTP 200 (0 items) | **PASS** |
| `/backtests` | backtests | 0 items | 0 items | 0 | HTTP 200 (0 items) | **PASS** |
| `/research/patterns` | research_patterns | 0 items | 0 items | 0 | HTTP 200 (0 items) | **PASS** |
| `/research/strategies` | research_strategies | 10 items | 3 items | 0 | HTTP 200 (0 items) | **PASS** |

---

## 5. UI ↔ API ↔ PostgreSQL Financial Reconciliation

- **Canonical Accounting Identity:** `equity = starting_balance + realized_pnl + unrealized_pnl`
- **Accounts Evaluated:** `130`
- **Identity Compliance:** `130 / 130 (100%)`
- **Exchange Isolation:** Confirmed independent scoping; zero cross-exchange balance blending.
- **Aggregate Starting Balance (Bybit):** `130,000.00 USDT`
- **Aggregate Current Equity (Bybit):** `130,000.00 USDT`
- **Aggregate Realized PnL (Bybit):** `0.00 USDT`

---

## 6. Findings & Anomalies Log

No defects, memory leaks, console errors, or financial discrepancies detected.

---

## 7. Artifact Manifest

All artifacts recorded during this audit run:
- [summary.md](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/summary.md)
- [routes.json](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/routes.json)
- [pagination.json](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/pagination.json)
- [strategy-matrix.json](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/strategy-matrix.json)
- [financial-reconciliation.json](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/financial-reconciliation.json)
- [findings.json](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/findings.json)
- [screenshots/](file:///home/thunder/work/traderbybit/reports/vector-ui-audit/screenshots)
