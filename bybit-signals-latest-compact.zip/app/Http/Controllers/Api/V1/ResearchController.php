<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1;

use App\Backtest\Infrastructure\Persistence\BacktestEquitySnapshotRecord;
use App\Backtest\Infrastructure\Persistence\BacktestReportRecord;
use App\Backtest\Infrastructure\Persistence\BacktestRunRecord;
use App\Backtest\Infrastructure\Persistence\BacktestSegmentRecord;
use App\Backtest\Infrastructure\Persistence\BacktestTradeRecord;
use App\Backtest\Jobs\RunBacktestJob;
use App\Http\Controllers\Controller;
use App\Http\Requests\V1\BacktestStoreRequest;
use App\Http\Requests\V1\MarketSeriesRequest;
use App\Http\Resources\V1\ResearchResource;
use App\Indicators\Application\IndicatorEngine;
use App\MarketData\Domain\Candle;
use App\MarketData\Domain\Interval;
use App\MarketData\Infrastructure\Persistence\CandleRecord;
use App\PaperTrading\Application\PerformanceStatisticsService;
use App\PaperTrading\Infrastructure\Persistence\EquitySnapshotRecord;
use App\PaperTrading\Infrastructure\Persistence\JournalEventRecord;
use App\PaperTrading\Infrastructure\Persistence\PaperAccountRecord;
use App\PaperTrading\Infrastructure\Persistence\PaperSignalStateRecord;
use App\PaperTrading\Infrastructure\Persistence\PositionFundingEventRecord;
use App\PaperTrading\Infrastructure\Persistence\RiskDecisionRecord;
use App\PaperTrading\Infrastructure\Persistence\VirtualExecutionRecord;
use App\PaperTrading\Infrastructure\Persistence\VirtualPositionRecord;
use App\Strategy\Infrastructure\Persistence\MarketContextRecord;
use App\Strategy\Infrastructure\Persistence\SignalRecord;
use DateTimeImmutable;
use Brick\Math\BigDecimal;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

final class ResearchController extends Controller
{
    private function ok(mixed $data): ResearchResource
    {
        return new ResearchResource($data);
    }

    private function symbol(string $symbol): string
    {
        $symbol = strtoupper($symbol);
        abort_unless(in_array($symbol, config('ui.symbols'), true), 404, 'Unsupported symbol.');

        return $symbol;
    }

    /** Keep default ledgers small even when clients omit pagination arguments. */
    private function perPage(Request $request): int
    {
        return max(1, min(50, $request->integer('per_page', 10)));
    }

    public function dashboard(PerformanceStatisticsService $statistics): ResearchResource
    {
        $account = PaperAccountRecord::query()->oldest()->first();
        $contexts = collect(config('ui.symbols'))->map(
            static fn (string $symbol) => MarketContextRecord::query()->where('symbol', $symbol)->latest('observed_at')->first()
        )->filter()->values();
        $recentSkips = SignalRecord::query()->where('side', 'SKIP')
            ->where('decision_time', '>=', now('UTC')->subDay())
            ->whereIn('symbol', config('ui.symbols'))
            ->cursor();
        $skipCounts = [];
        foreach ($recentSkips as $skip) {
            foreach ($skip->reasons ?? [] as $reason) {
                if (is_string($reason)) {
                    $skipCounts[$reason] = ($skipCounts[$reason] ?? 0) + 1;
                }
            }
        }
        arsort($skipCounts);
        $skipReasons = array_slice($skipCounts, 0, 8, true);

        return $this->ok([
            'market' => $contexts,
            'account' => $account,
            'portfolio' => $account ? array_merge($statistics->accountSummary($account), [
                'open_positions' => VirtualPositionRecord::query()->where('paper_account_id', $account->id)->whereNull('closed_at')->count(),
                'pending_entry_signals' => PaperSignalStateRecord::query()->where('paper_account_id', $account->id)->where('status', 'PENDING_ENTRY')->count(),
            ]) : null,
            'signals' => SignalRecord::query()->whereIn('side', ['BUY', 'SELL'])->latest('decision_time')->limit(8)->get(['id', 'symbol', 'side', 'quality_class', 'score', 'entry_low', 'entry_high', 'stop_loss', 'take_profit_1', 'take_profit_2', 'expires_at', 'reasons', 'decision_time']),
            'recent_decisions' => SignalRecord::query()->whereIn('symbol', config('ui.symbols'))->latest('decision_time')->limit(8)->get(['id', 'symbol', 'side', 'decision_time', 'reasons']),
            'skip_reasons_24h' => $skipReasons,
            'positions' => VirtualPositionRecord::query()->whereNull('closed_at')->latest('opened_at')->limit(10)->get(['id', 'symbol', 'side', 'status', 'entry_price', 'net_pnl', 'unrealized_pnl']),
            'performance' => $account ? Cache::remember('paper:dashboard:performance:'.$account->id, 60, fn () => $statistics->calculate($account->id)->metrics) : null,
            'research_settings' => [
                'starting_balance' => config('backtest.starting_balance'),
                'strategy_version' => config('strategy.version'),
                'execution_model_version' => config('paper.execution_version'),
            ],
        ]);
    }

    public function candles(MarketSeriesRequest $r, string $symbol): ResearchResource
    {
        $q = CandleRecord::query()->where(['symbol' => $this->symbol($symbol), 'interval' => (string) $r->integer('interval', 15), 'is_closed' => true])->latest('open_time')->limit($r->integer('limit', 500));
        if ($r->filled('to')) {
            $q->where('open_time', '<', new DateTimeImmutable($r->string('to')));
        }

        return $this->ok($q->get()->reverse()->values());
    }

    public function indicators(MarketSeriesRequest $r, string $symbol, IndicatorEngine $engine): ResearchResource
    {
        $query = CandleRecord::query()->where(['symbol' => $this->symbol($symbol), 'interval' => (string) $r->integer('interval', 15), 'is_closed' => true]);
        if ($r->filled('to')) {
            $query->where('open_time', '<', new DateTimeImmutable($r->string('to')));
        }
        $rows = $query->latest('open_time')->limit($r->integer('limit', 300))->get()->reverse()->values();
        if ($rows->isEmpty()) {
            return $this->ok(['times' => [], 'series' => null]);
        }

        $i = Interval::parse((string) $r->integer('interval', 15));
        $candles = $rows->map(fn ($x) => new Candle($x->exchange, $x->category, $x->symbol, $i, $x->open_time->getTimestamp() * 1000, $x->open, $x->high, $x->low, $x->close, $x->volume, $x->turnover, true))->all();

        return $this->ok(['times' => $rows->pluck('open_time'), 'series' => $engine->calculate($candles)]);
    }

    public function context(string $symbol): ResearchResource
    {
        return $this->ok(MarketContextRecord::query()->where('symbol', $this->symbol($symbol))->latest('observed_at')->first());
    }

    public function signals(Request $r): ResearchResource
    {
        $q = SignalRecord::query();
        foreach (['symbol', 'side', 'quality_class', 'strategy_version'] as $f) {
            if ($r->filled($f)) {
                $q->where($f, $r->string($f));
            }
        }
        if ($r->filled('search')) {
            $q->where('symbol', 'like', '%'.strtoupper($r->string('search')).'%');
        }

        return $this->ok($q->latest('decision_time')->paginate($this->perPage($r), ['id', 'symbol', 'side', 'quality_class', 'score', 'decision_time', 'candle_close_time', 'expires_at', 'entry_low', 'entry_high', 'stop_loss', 'take_profit_1', 'take_profit_2', 'strategy_version']));
    }

    public function signal(string $id): ResearchResource
    {
        return $this->ok(SignalRecord::query()->findOrFail($id));
    }

    public function positions(Request $r): ResearchResource
    {
        $q = VirtualPositionRecord::query();
        if ($r->filled('account')) {
            $q->where('paper_account_id', $r->string('account'));
        }
        if ($r->filled('symbol')) {
            $q->where('symbol', $this->symbol($r->string('symbol')));
        }
        if ($r->filled('search')) {
            $q->where('symbol', 'like', '%'.strtoupper($r->string('search')).'%');
        }

        $page = $q->latest('opened_at')->paginate($this->perPage($r));
        $latestPrices = collect($page->items())->pluck('symbol')->unique()->mapWithKeys(
            static fn (string $symbol) => [$symbol => CandleRecord::query()->where('symbol', $symbol)->where('interval', '5')->where('is_closed', true)->latest('open_time')->first(['symbol', 'close'])]
        );
        $page->through(function (VirtualPositionRecord $position) use ($latestPrices): array {
            $referenceAt = $position->closed_at ?? $position->last_processed_event_at ?? $position->opened_at;

            return array_merge($position->toArray(), [
                'current_reference_price' => $latestPrices->get($position->symbol)?->close,
                'duration_seconds' => max(0, $referenceAt->getTimestamp() - $position->opened_at->getTimestamp()),
                'maximum_holding_remaining_seconds' => max(0, $position->maximum_holding_until->getTimestamp() - $referenceAt->getTimestamp()),
            ]);
        });

        return $this->ok($page);
    }

    public function position(Request $request, string $id): ResearchResource
    {
        $p = VirtualPositionRecord::query()->findOrFail($id);

        return $this->ok([
            'mode' => 'FORWARD_PAPER',
            'position' => $p,
            'signal' => SignalRecord::query()->find($p->signal_id),
            'executions' => VirtualExecutionRecord::query()->where('position_id', $id)->latest('market_event_at')->paginate($this->perPage($request), ['id', 'type', 'quantity', 'price', 'commission', 'slippage', 'gross_pnl', 'market_event_at', 'price_source', 'ambiguous_execution'], 'executions_page'),
            'funding_events' => PositionFundingEventRecord::query()->where('position_id', $id)->latest('funding_at')->paginate($this->perPage($request), ['id', 'rate', 'amount', 'funding_at'], 'funding_page'),
            'journal' => JournalEventRecord::query()->where('position_id', $id)->latest('occurred_at')->paginate($this->perPage($request), ['id', 'event_type', 'occurred_at'], 'journal_page'),
        ]);
    }

    public function journal(Request $r): ResearchResource
    {
        $q = JournalEventRecord::query();
        if ($r->filled('account')) {
            $q->where('paper_account_id', $r->string('account'));
        }

        return $this->ok($q->latest('occurred_at')->latest('sequence')->paginate($this->perPage($r), ['sequence', 'id', 'paper_account_id', 'position_id', 'signal_id', 'event_type', 'occurred_at']));
    }

    public function statistics(Request $r, PerformanceStatisticsService $s): ResearchResource
    {
        $a = $r->string('account')->toString() ?: PaperAccountRecord::query()->value('id');
        if (! $a) {
            return $this->ok(['metrics' => null, 'equity' => [], 'equity_pagination' => ['current_page' => 1, 'last_page' => 1], 'breakdowns' => [], 'period_pnl' => []]);
        }
        $report = Cache::remember('paper:statistics:'.$a, 60, fn () => $s->calculate($a));
        $closed = VirtualPositionRecord::query()->where('paper_account_id', $a)->whereNotNull('closed_at');
        $group = static fn (string $field) => (clone $closed)
            ->selectRaw($field.', COUNT(*) AS trades, SUM(net_pnl) AS net_pnl, SUM(CASE WHEN net_pnl > 0 THEN 1 ELSE 0 END) AS winning_trades')
            ->groupBy($field)->orderBy($field)->get();

        // Never send an unbounded equity curve or per-trade R array to the browser.
        $equityPage = max(1, $r->integer('equity_page', 1));
        $equity = EquitySnapshotRecord::query()->where('paper_account_id', $a)
            ->latest('recorded_at')->latest('id')->paginate(100, ['recorded_at', 'equity', 'drawdown_percent'], 'equity_page', $equityPage);
        $rPage = max(1, $r->integer('r_page', 1));
        $rMultiples = (clone $closed)->whereNotNull('r_multiple')->latest('closed_at')
            ->paginate(10, ['id', 'r_multiple'], 'r_page', $rPage);

        return $this->ok([
            'metrics' => $report->metrics,
            'data_quality' => $report->dataQuality,
            'equity' => collect($equity->items())->reverse()->values(),
            'equity_pagination' => ['current_page' => $equity->currentPage(), 'last_page' => $equity->lastPage(), 'total' => $equity->total()],
            'breakdowns' => [
                'symbols' => $group('symbol'), 'sides' => $group('side'), 'quality_classes' => $group('quality_class'),
                'r_distribution' => collect($rMultiples->items())->pluck('r_multiple')->reverse()->values(),
            ],
            'r_pagination' => ['current_page' => $rMultiples->currentPage(), 'last_page' => $rMultiples->lastPage(), 'total' => $rMultiples->total()],
            'period_pnl' => $this->periodPnl((clone $closed)->oldest('closed_at')->cursor(), max(1, $r->integer('period_page', 1))),
        ]);
    }

    /** Aggregate with a cursor, returning only ten recent periods to the client. */
    private function periodPnl(iterable $positions, int $page): array
    {
        $formats = ['daily' => 'Y-m-d', 'weekly' => 'o-\WW', 'monthly' => 'Y-m'];
        $buckets = ['daily' => [], 'weekly' => [], 'monthly' => []];
        foreach ($positions as $position) {
            foreach ($formats as $name => $format) {
                $key = $position->closed_at->format($format);
                $buckets[$name][$key] = ($buckets[$name][$key] ?? BigDecimal::zero())->plus($position->net_pnl);
            }
        }
        $result = [];
        foreach ($buckets as $name => $byPeriod) {
            ksort($byPeriod);
            $running = BigDecimal::zero();
            $items = [];
            foreach ($byPeriod as $period => $net) {
                $running = $running->plus($net);
                $items[] = ['period' => $period, 'net_pnl' => (string) $net, 'cumulative_net_pnl' => (string) $running];
            }
            $items = array_reverse($items); // newest first for consistent pagination
            $result[$name] = [
                'data' => array_reverse(array_slice($items, ($page - 1) * 10, 10)),
                'current_page' => $page, 'last_page' => max(1, (int) ceil(count($items) / 10)),
            ];
        }

        return $result;
    }

    public function risk(Request $r): ResearchResource
    {
        $a = $r->string('account')->toString() ?: PaperAccountRecord::query()->value('id');
        $decisions = $a ? RiskDecisionRecord::query()->where('paper_account_id', $a)
            ->latest('decided_at')->paginate($this->perPage($r), ['id', 'signal_id', 'allowed', 'reasons', 'decided_at']) : null;

        return $this->ok([
            'account' => $a ? PaperAccountRecord::query()->find($a) : null,
            'decisions' => $decisions ?? ['data' => [], 'current_page' => 1, 'last_page' => 1],
            'limits' => config('paper.portfolio'),
        ]);
    }

    public function backtests(Request $r): ResearchResource
    {
        return $this->ok(BacktestRunRecord::query()->latest('created_at')->paginate($this->perPage($r),
            ['id', 'type', 'status', 'from_at', 'to_at', 'symbols', 'strategy_version', 'progress', 'created_at', 'completed_at']));
    }

    public function backtest(Request $request, string $id): ResearchResource
    {
        $run = BacktestRunRecord::query()->findOrFail($id);

        return $this->ok([
            'run' => $run->only(['id', 'type', 'status', 'progress', 'strategy_version', 'from_at', 'to_at', 'metrics']),
            'segments' => BacktestSegmentRecord::query()->where('backtest_run_id', $id)
                ->orderBy('window_index')->paginate($this->perPage($request),
                    ['id', 'kind', 'window_index', 'from_at', 'to_at', 'status', 'metrics']),
        ]);
    }

    public function report(Request $request, string $id): ResearchResource
    {
        $run = BacktestRunRecord::query()->findOrFail($id);
        $trades = BacktestTradeRecord::query()->where('backtest_run_id', $id)
            ->latest('closed_at')->paginate($this->perPage($request),
                ['id', 'symbol', 'side', 'quality_class', 'opened_at', 'closed_at', 'entry_price', 'exit_price', 'net_pnl', 'r_multiple', 'close_reason', 'ambiguous_execution', 'funding_complete']);
        $equity = BacktestEquitySnapshotRecord::query()->where('backtest_run_id', $id)
            ->latest('recorded_at')->latest('id')->paginate(100, ['recorded_at', 'equity', 'drawdown_percent'], 'equity_page', max(1, $request->integer('equity_page', 1)));

        return $this->ok([
            'run' => ['id' => $run->id, 'status' => $run->status, 'metrics' => $run->metrics, 'progress' => $run->progress],
            // Report JSON can contain entire simulation traces: never include it in list responses.
            'reports' => BacktestReportRecord::query()->where('backtest_run_id', $id)->get(['id', 'kind']),
            'trades' => $trades,
            'equity' => collect($equity->items())->reverse()->values(),
            'equity_pagination' => ['current_page' => $equity->currentPage(), 'last_page' => $equity->lastPage(), 'total' => $equity->total()],
        ]);
    }

    public function store(BacktestStoreRequest $r): JsonResponse
    {
        $v = $r->validated();
        RunBacktestJob::dispatch($v['symbols'], $v['from'].'T00:00:00Z', $v['to'].'T00:00:00Z', $v['mode'] === 'walk_forward');

        return response()->json([
            'schema_version' => '1.0.0',
            'research_mode' => true,
            'data' => ['status' => 'QUEUED'],
        ], 202);
    }
}
